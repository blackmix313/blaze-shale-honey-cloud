import React, { useState, useEffect, useRef } from 'react';
import { LogEntry } from '../types/vpn';
import { playSound } from '../utils/audio';
import { 
  Terminal, 
  X, 
  Copy, 
  Check, 
  Trash2, 
  Download, 
  Play, 
  Pause, 
  Filter,
  Layers
} from 'lucide-react';

interface DiagnosticsLogModalProps {
  logs: LogEntry[];
  onClearLogs: () => void;
  onClose: () => void;
}

export const DiagnosticsLogModal: React.FC<DiagnosticsLogModalProps> = ({
  logs,
  onClearLogs,
  onClose
}) => {
  const [filterLevel, setFilterLevel] = useState<string>('ALL');
  const [autoScroll, setAutoScroll] = useState(true);
  const [copied, setCopied] = useState(false);
  const logContainerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (autoScroll && logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  const handleCopyLogs = () => {
    const text = logs
      .map((l) => `[${l.timestamp}] [${l.level}] [${l.tag}] ${l.message}`)
      .join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    playSound.select();
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportFile = () => {
    const text = logs
      .map((l) => `[${l.timestamp}] [${l.level}] [${l.tag}] ${l.message}`)
      .join('\n');
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `aether-vpn-logs-${Date.now()}.log`;
    link.click();
    URL.revokeObjectURL(url);
    playSound.connected();
  };

  const filteredLogs = logs.filter((l) => {
    if (filterLevel === 'ALL') return true;
    return l.level === filterLevel;
  });

  const getLevelColor = (level: LogEntry['level']) => {
    switch (level) {
      case 'INFO': return 'text-[#00f0ff] bg-[#00f0ff]/10 border-[#00f0ff]/30';
      case 'DPI': return 'text-[#ffe600] bg-[#ffe600]/10 border-[#ffe600]/30';
      case 'TUN': return 'text-[#00ff66] bg-[#00ff66]/10 border-[#00ff66]/30';
      case 'SOUL': return 'text-[#ff2a2a] bg-[#ff2a2a]/10 border-[#ff2a2a]/30';
      case 'WARN': return 'text-[#ff9900] bg-[#ff9900]/10 border-[#ff9900]/30';
      case 'ERROR': return 'text-[#ff3b30] bg-[#ff3b30]/10 border-[#ff3b30]/30';
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#080b1a] border-2 border-[#00ff66] rounded-xl max-w-3xl w-full h-[85vh] flex flex-col shadow-[0_0_25px_rgba(0,255,102,0.25)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#0d142e] border-b border-[#1c2752]">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-[#00ff66]" />
            <h2 className="font-pixel text-xs text-white uppercase tracking-wider">
              Aether Core Engine Live Diagnostics & TUN Logs
            </h2>
          </div>
          <button
            onClick={() => {
              onClose();
              playSound.cancel();
            }}
            className="p-1 rounded text-[#7b8bbd] hover:text-white hover:bg-[#1a2347] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Toolbar */}
        <div className="p-2.5 bg-[#0a0f26] border-b border-[#182247] flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <Filter className="w-3.5 h-3.5 text-[#6c7ca8] mr-1" />
            {['ALL', 'TUN', 'DPI', 'SOUL', 'INFO', 'WARN'].map((lvl) => (
              <button
                key={lvl}
                onClick={() => {
                  setFilterLevel(lvl);
                  playSound.cursor();
                }}
                className={`px-2 py-0.5 rounded text-[10px] transition-colors ${
                  filterLevel === lvl
                    ? 'bg-[#00ff66] text-black font-bold shadow-[0_0_6px_rgba(0,255,102,0.4)]'
                    : 'bg-[#121838] text-[#7a8bb8] hover:text-white'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setAutoScroll(!autoScroll)}
              className={`px-2 py-1 rounded text-[10px] flex items-center gap-1 border transition-colors ${
                autoScroll
                  ? 'bg-[#142345] border-[#00f0ff]/40 text-[#00f0ff]'
                  : 'bg-[#121838] border-[#222e5a] text-[#7888b5]'
              }`}
              title="Toggle Auto-Scroll"
            >
              {autoScroll ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
              <span>Auto-Scroll</span>
            </button>

            <button
              onClick={handleCopyLogs}
              className="px-2 py-1 bg-[#121838] hover:bg-[#1d2757] border border-[#222e5a] text-[#a5b4e0] rounded text-[10px] flex items-center gap-1 transition-colors"
            >
              {copied ? <Check className="w-3 h-3 text-[#00ff66]" /> : <Copy className="w-3 h-3" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>

            <button
              onClick={handleExportFile}
              className="px-2 py-1 bg-[#121838] hover:bg-[#1d2757] border border-[#222e5a] text-[#a5b4e0] rounded text-[10px] flex items-center gap-1 transition-colors"
              title="Export as .log file"
            >
              <Download className="w-3 h-3" />
              <span>Export</span>
            </button>

            <button
              onClick={() => {
                onClearLogs();
                playSound.cancel();
              }}
              className="px-2 py-1 bg-[#121838] hover:bg-red-950/50 border border-[#222e5a] hover:border-red-500/50 text-[#a5b4e0] hover:text-red-300 rounded text-[10px] flex items-center gap-1 transition-colors"
              title="Clear Console"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear</span>
            </button>
          </div>
        </div>

        {/* Log Viewer Console */}
        <div
          ref={logContainerRef}
          className="flex-1 overflow-y-auto p-3.5 bg-[#030612] font-mono text-[11px] space-y-1.5 selection:bg-[#00ff66]/30 selection:text-white"
        >
          {filteredLogs.length === 0 ? (
            <div className="text-[#51618a] italic py-8 text-center">No logs matching filter</div>
          ) : (
            filteredLogs.map((log) => (
              <div key={log.id} className="flex items-start gap-2 leading-relaxed hover:bg-[#0a0f28] px-1 py-0.5 rounded">
                <span className="text-[#4e5e8c] shrink-0 text-[10px]">{log.timestamp}</span>
                <span
                  className={`px-1 rounded text-[9px] font-bold border shrink-0 uppercase ${getLevelColor(
                    log.level
                  )}`}
                >
                  {log.level}
                </span>
                <span className="text-[#8499d6] font-bold shrink-0">[{log.tag}]</span>
                <span className="text-[#e2e8f8] break-all">{log.message}</span>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-2.5 bg-[#0d142e] border-t border-[#1c2752] flex items-center justify-between text-[10px] font-mono text-[#7888b5]">
          <span>Engine Status: <strong className="text-[#00ff66]">RUNNING</strong> (Wintun I/O active)</span>
          <span>Showing {filteredLogs.length} events</span>
        </div>
      </div>
    </div>
  );
};
