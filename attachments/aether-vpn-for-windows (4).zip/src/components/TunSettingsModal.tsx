import React, { useState } from 'react';
import { TunConfig } from '../types/vpn';
import { playSound } from '../utils/audio';
import { 
  Layers, 
  X, 
  Check, 
  Shield, 
  Sliders, 
  Plus, 
  Trash2, 
  HardDrive, 
  Network,
  RotateCcw,
  Info
} from 'lucide-react';

interface TunSettingsModalProps {
  config: TunConfig;
  onSave: (config: TunConfig) => void;
  onClose: () => void;
}

export const TunSettingsModal: React.FC<TunSettingsModalProps> = ({
  config,
  onSave,
  onClose
}) => {
  const [formData, setFormData] = useState<TunConfig>({ ...config });
  const [newAppName, setNewAppName] = useState('');
  const [newAppPath, setNewAppPath] = useState('');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSave = () => {
    onSave(formData);
    playSound.tunEngage();
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 600);
  };

  const handleAddApp = () => {
    if (!newAppName.trim()) return;
    const path = newAppPath.trim() || `C:\\Program Files\\${newAppName}\\${newAppName.toLowerCase()}.exe`;
    setFormData({
      ...formData,
      splitTunneling: {
        ...formData.splitTunneling,
        apps: [
          ...formData.splitTunneling.apps,
          { name: newAppName.trim(), path, icon: 'Gamepad2', enabled: true }
        ]
      }
    });
    setNewAppName('');
    setNewAppPath('');
    playSound.select();
  };

  const handleRemoveApp = (idx: number) => {
    const updated = [...formData.splitTunneling.apps];
    updated.splice(idx, 1);
    setFormData({
      ...formData,
      splitTunneling: {
        ...formData.splitTunneling,
        apps: updated
      }
    });
    playSound.cancel();
  };

  const handleToggleApp = (idx: number) => {
    const updated = [...formData.splitTunneling.apps];
    updated[idx].enabled = !updated[idx].enabled;
    setFormData({
      ...formData,
      splitTunneling: {
        ...formData.splitTunneling,
        apps: updated
      }
    });
    playSound.cursor();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#090c1e] border-2 border-[#00f0ff] rounded-xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-[0_0_25px_rgba(0,240,255,0.25)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#0d122c] border-b border-[#1c244c]">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#00f0ff]" />
            <h2 className="font-pixel text-xs text-white uppercase tracking-wider">
              ACT: TUN Mode & Wintun Driver Configuration
            </h2>
          </div>
          <button
            onClick={() => {
              onClose();
              playSound.cancel();
            }}
            className="p-1 rounded text-[#7b8bbd] hover:text-white hover:bg-[#1a2347] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs font-mono text-[#d6deff]">
          {/* Top Banner */}
          <div className="p-3 bg-[#111738] border border-[#232f66] rounded-lg flex items-start gap-2.5">
            <Info className="w-4 h-4 text-[#00f0ff] shrink-0 mt-0.5" />
            <p className="text-[11px] text-[#9db2ec] leading-relaxed">
              Windows TUN Mode installs the official high-speed <strong className="text-white">Wintun Layer-3</strong> virtual adapter driver. All system IP traffic, games, and background applications route securely through the Aether kernel tunnel.
            </p>
          </div>

          {/* Section 1: Driver & Adapter Settings */}
          <div className="space-y-3 bg-[#0b0f26] p-3.5 rounded-lg border border-[#1d2654]">
            <h3 className="font-pixel text-[10px] text-[#00f0ff] uppercase">1. Virtual TUN Driver Engine</h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {[
                { id: 'wintun', name: 'Wintun (Recommended)', desc: 'Fastest Layer-3 I/O' },
                { id: 'wireguard-nt', name: 'WireGuard-NT', desc: 'Kernel-mode Driver' },
                { id: 'tap-windows6', name: 'TAP-Windows6', desc: 'Legacy TAP Adapter' }
              ].map((d) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => {
                    setFormData({ ...formData, driver: d.id as any });
                    playSound.select();
                  }}
                  className={`p-2.5 rounded border text-left transition-all ${
                    formData.driver === d.id
                      ? 'border-[#00f0ff] bg-[#141b40] shadow-[0_0_8px_rgba(0,240,255,0.3)]'
                      : 'border-[#1e2752] bg-[#0d122b] hover:border-[#384687]'
                  }`}
                >
                  <div className="font-bold text-white text-[11px]">{d.name}</div>
                  <div className="text-[9px] text-[#7a8bb8] mt-0.5">{d.desc}</div>
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
              <div>
                <label className="text-[10px] text-[#8696c7] block mb-1">Adapter Interface Name</label>
                <input
                  type="text"
                  value={formData.adapterName}
                  onChange={(e) => setFormData({ ...formData, adapterName: e.target.value })}
                  className="w-full bg-[#111636] border border-[#232f63] rounded px-2.5 py-1.5 text-white focus:border-[#00f0ff] outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#8696c7] block mb-1">Virtual Tunnel IP / CIDR</label>
                <input
                  type="text"
                  value={formData.virtualIp}
                  onChange={(e) => setFormData({ ...formData, virtualIp: e.target.value })}
                  className="w-full bg-[#111636] border border-[#232f63] rounded px-2.5 py-1.5 text-white focus:border-[#00f0ff] outline-none"
                />
              </div>
            </div>

            {/* MTU Slider */}
            <div className="mt-3">
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-[#8696c7]">MTU (Maximum Transmission Unit):</span>
                <span className="text-[#00f0ff] font-bold">{formData.mtu} bytes</span>
              </div>
              <input
                type="range"
                min="1280"
                max="1500"
                step="10"
                value={formData.mtu}
                onChange={(e) => setFormData({ ...formData, mtu: parseInt(e.target.value) })}
                className="w-full accent-[#00f0ff] cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-[#5d6c99]">
                <span>1280 (Min IPv6)</span>
                <span>1420 (WireGuard/MASQUE Default)</span>
                <span>1500 (Standard Ethernet)</span>
              </div>
            </div>
          </div>

          {/* Section 2: Security & Routing Controls */}
          <div className="space-y-2.5 bg-[#0b0f26] p-3.5 rounded-lg border border-[#1d2654]">
            <h3 className="font-pixel text-[10px] text-[#00ff66] uppercase">2. Security & Routing Options</h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <label className="flex items-center gap-2.5 p-2 rounded bg-[#101533] border border-[#1f2854] cursor-pointer hover:border-[#38488c]">
                <input
                  type="checkbox"
                  checked={formData.killSwitch}
                  onChange={(e) => setFormData({ ...formData, killSwitch: e.target.checked })}
                  className="accent-[#00f0ff] w-4 h-4 rounded"
                />
                <div>
                  <div className="font-bold text-white text-[11px]">Windows Kill Switch</div>
                  <div className="text-[9px] text-[#7888b5]">Block all unencrypted traffic if tunnel disconnects</div>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2 rounded bg-[#101533] border border-[#1f2854] cursor-pointer hover:border-[#38488c]">
                <input
                  type="checkbox"
                  checked={formData.strictRouting}
                  onChange={(e) => setFormData({ ...formData, strictRouting: e.target.checked })}
                  className="accent-[#00f0ff] w-4 h-4 rounded"
                />
                <div>
                  <div className="font-bold text-white text-[11px]">Strict Route Override</div>
                  <div className="text-[9px] text-[#7888b5]">Prevent default gateway route metric conflicts</div>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2 rounded bg-[#101533] border border-[#1f2854] cursor-pointer hover:border-[#38488c]">
                <input
                  type="checkbox"
                  checked={formData.fakeDns}
                  onChange={(e) => setFormData({ ...formData, fakeDns: e.target.checked })}
                  className="accent-[#00f0ff] w-4 h-4 rounded"
                />
                <div>
                  <div className="font-bold text-white text-[11px]">Aether FakeDNS Pool</div>
                  <div className="text-[9px] text-[#7888b5]">Zero DNS latency via 198.18.0.0/15 pool</div>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2 rounded bg-[#101533] border border-[#1f2854] cursor-pointer hover:border-[#38488c]">
                <input
                  type="checkbox"
                  checked={formData.bypassLan}
                  onChange={(e) => setFormData({ ...formData, bypassLan: e.target.checked })}
                  className="accent-[#00f0ff] w-4 h-4 rounded"
                />
                <div>
                  <div className="font-bold text-white text-[11px]">Bypass Local LAN</div>
                  <div className="text-[9px] text-[#7888b5]">Preserve local printers, NAS, and LAN games</div>
                </div>
              </label>
            </div>
          </div>

          {/* Section 3: Split Tunneling */}
          <div className="space-y-3 bg-[#0b0f26] p-3.5 rounded-lg border border-[#1d2654]">
            <div className="flex items-center justify-between">
              <h3 className="font-pixel text-[10px] text-[#ffe600] uppercase">3. Windows Application Split Tunneling</h3>
              <label className="flex items-center gap-2 cursor-pointer">
                <span className="text-[10px] text-[#8fa0cf]">Enable Split Tunneling</span>
                <input
                  type="checkbox"
                  checked={formData.splitTunneling.enabled}
                  onChange={(e) => setFormData({
                    ...formData,
                    splitTunneling: { ...formData.splitTunneling, enabled: e.target.checked }
                  })}
                  className="accent-[#ffe600] w-4 h-4 rounded"
                />
              </label>
            </div>

            {formData.splitTunneling.enabled && (
              <div className="space-y-2 pt-1">
                <div className="flex items-center gap-3 text-[10px]">
                  <span className="text-[#8897c4]">Mode:</span>
                  <label className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      name="splitMode"
                      checked={formData.splitTunneling.mode === 'exclude'}
                      onChange={() => setFormData({
                        ...formData,
                        splitTunneling: { ...formData.splitTunneling, mode: 'exclude' }
                      })}
                      className="accent-[#ffe600]"
                    />
                    <span>Bypass VPN for selected apps (Exclude)</span>
                  </label>
                  <label className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="radio"
                      name="splitMode"
                      checked={formData.splitTunneling.mode === 'include'}
                      onChange={() => setFormData({
                        ...formData,
                        splitTunneling: { ...formData.splitTunneling, mode: 'include' }
                      })}
                      className="accent-[#ffe600]"
                    />
                    <span>Only route selected apps (Include)</span>
                  </label>
                </div>

                {/* App list */}
                <div className="space-y-1.5 max-h-32 overflow-y-auto pr-1">
                  {formData.splitTunneling.apps.map((app, idx) => (
                    <div key={idx} className="flex items-center justify-between p-2 rounded bg-[#101430] border border-[#1e2752]">
                      <label className="flex items-center gap-2 cursor-pointer flex-1">
                        <input
                          type="checkbox"
                          checked={app.enabled}
                          onChange={() => handleToggleApp(idx)}
                          className="accent-[#ffe600]"
                        />
                        <div>
                          <div className="font-bold text-white text-[11px]">{app.name}</div>
                          <div className="text-[8px] text-[#6979a6]">{app.path}</div>
                        </div>
                      </label>
                      <button
                        onClick={() => handleRemoveApp(idx)}
                        className="text-[#6979a6] hover:text-red-400 p-1"
                        title="Remove app"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Add new app */}
                <div className="flex gap-2 pt-1">
                  <input
                    type="text"
                    placeholder="App Name (e.g. Valorant.exe)"
                    value={newAppName}
                    onChange={(e) => setNewAppName(e.target.value)}
                    className="flex-1 bg-[#101430] border border-[#212c5b] rounded px-2.5 py-1 text-white text-[10px] outline-none"
                  />
                  <button
                    onClick={handleAddApp}
                    className="px-3 py-1 bg-[#1f2854] hover:bg-[#ffe600] hover:text-black text-white rounded text-[10px] font-bold transition-colors flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add .EXE
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#0d122c] border-t border-[#1c244c] flex items-center justify-between">
          <button
            onClick={() => {
              setFormData({
                enabled: true,
                driver: 'wintun',
                adapterName: 'Aether-TUN0',
                virtualIp: '10.66.77.2/24',
                gateway: '10.66.77.1',
                mtu: 1420,
                dnsServers: ['1.1.1.1', '1.0.0.1'],
                strictRouting: true,
                ipv6Routing: false,
                fakeDns: true,
                bypassLan: true,
                killSwitch: true,
                splitTunneling: {
                  enabled: false,
                  mode: 'exclude',
                  apps: []
                }
              });
              playSound.select();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-[10px] font-mono text-[#7b8cb8] hover:text-white hover:bg-[#141b3d] transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
            Reset Defaults
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                playSound.cancel();
              }}
              className="px-3.5 py-1.5 rounded bg-[#131a3d] hover:bg-[#1d2757] text-[#9aa7d4] text-[10px] font-pixel transition-colors"
            >
              CANCEL
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-1.5 rounded bg-[#00f0ff] hover:bg-[#5ff6ff] text-black text-[10px] font-pixel shadow-[0_0_10px_rgba(0,240,255,0.5)] transition-all flex items-center gap-1.5"
            >
              {saveSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  APPLIED!
                </>
              ) : (
                'APPLY TUN DRIVER'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
