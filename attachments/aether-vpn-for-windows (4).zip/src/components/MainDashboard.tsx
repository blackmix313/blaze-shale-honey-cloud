import React, { useEffect, useRef, useState } from 'react';
import { 
  ServerNode, 
  ConnectionState, 
  SoulColor, 
  TrafficStats, 
  TunConfig, 
  DpiEvasionConfig 
} from '../types/vpn';
import { SoulHeart } from './SoulHeart';
import { DELTARUNE_QUOTES } from '../utils/vpnEngine';
import { playSound } from '../utils/audio';
import { 
  ArrowDown, 
  ArrowUp, 
  ShieldCheck, 
  Globe2, 
  Zap, 
  Lock, 
  Cpu, 
  Radio, 
  ChevronRight,
  MessageCircle,
  Layers,
  Sparkles
} from 'lucide-react';

interface MainDashboardProps {
  currentServer: ServerNode;
  connectionState: ConnectionState;
  soulColor: SoulColor;
  trafficStats: TrafficStats;
  tunConfig: TunConfig;
  dpiConfig: DpiEvasionConfig;
  onToggleConnect: () => void;
  onOpenServers: () => void;
  onOpenTun: () => void;
  onOpenDpi: () => void;
  onOpenQuickSetup: () => void;
}

export const MainDashboard: React.FC<MainDashboardProps> = ({
  currentServer,
  connectionState,
  soulColor,
  trafficStats,
  tunConfig,
  dpiConfig,
  onToggleConnect,
  onOpenServers,
  onOpenTun,
  onOpenDpi,
  onOpenQuickSetup
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [quoteIndex, setQuoteIndex] = useState(0);
  const [displayedText, setDisplayedText] = useState('');
  const currentQuote = DELTARUNE_QUOTES[quoteIndex];

  // Typewriter effect for dialogue box
  useEffect(() => {
    setDisplayedText('');
    let currentIdx = 0;
    const fullText = currentQuote.quote;
    const interval = setInterval(() => {
      if (currentIdx < fullText.length) {
        setDisplayedText(fullText.slice(0, currentIdx + 1));
        currentIdx++;
      } else {
        clearInterval(interval);
      }
    }, 25);

    return () => clearInterval(interval);
  }, [quoteIndex]);

  const handleNextQuote = () => {
    setQuoteIndex((prev) => (prev + 1) % DELTARUNE_QUOTES.length);
    playSound.select();
  };

  // Real-time Traffic Canvas Graph Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let offset = 0;
    const history: number[] = Array(50).fill(10);

    const render = () => {
      const isConnected = connectionState === 'CONNECTED';
      const width = canvas.width;
      const height = canvas.height;

      ctx.clearRect(0, 0, width, height);

      // Background subtle grid
      ctx.strokeStyle = '#121833';
      ctx.lineWidth = 1;
      for (let x = 0; x < width; x += 20) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += 15) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      if (isConnected) {
        // Push current speed normalized value
        const speedMb = trafficStats.downloadSpeed / (1024 * 1024);
        const norm = Math.min(height - 10, Math.max(8, speedMb * 6 + 12 + Math.sin(offset) * 4));
        history.push(norm);
        if (history.length > 50) history.shift();

        // Draw Waveform Gradient
        const gradient = ctx.createLinearGradient(0, 0, 0, height);
        gradient.addColorStop(0, 'rgba(0, 240, 255, 0.4)');
        gradient.addColorStop(1, 'rgba(0, 240, 255, 0.0)');

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(0, height);

        const step = width / (history.length - 1);
        for (let i = 0; i < history.length; i++) {
          const x = i * step;
          const y = height - history[i];
          if (i === 0) ctx.lineTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.lineTo(width, height);
        ctx.closePath();
        ctx.fill();

        // Wave line
        ctx.strokeStyle = '#00f0ff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        for (let i = 0; i < history.length; i++) {
          const x = i * step;
          const y = height - history[i];
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      } else {
        // Flat idle line
        ctx.strokeStyle = '#222d57';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(0, height - 10);
        ctx.lineTo(width, height - 10);
        ctx.stroke();
      }

      offset += 0.1;
      animationFrameId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animationFrameId);
  }, [connectionState, trafficStats.downloadSpeed]);

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatSpeed = (bytesPerSec: number) => {
    if (bytesPerSec === 0) return '0.00 KB/s';
    const mbps = bytesPerSec / (1024 * 1024);
    if (mbps >= 1) return `${mbps.toFixed(2)} MB/s`;
    const kbps = bytesPerSec / 1024;
    return `${kbps.toFixed(1)} KB/s`;
  };

  const formatUptime = (sec: number) => {
    const hrs = Math.floor(sec / 3600);
    const mins = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4 max-w-6xl mx-auto w-full">
      {/* Top Deltarune Battle Status HUD: TP Bar, HP Bar, Soul Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Tension Points (TP) Gauge */}
        <div className="bg-[#0b0e20] border-2 border-[#1c234a] rounded-lg p-3 relative overflow-hidden flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-[#ff9900]" />
              <span className="font-pixel text-[10px] text-[#ff9900] tracking-wider">
                TP (TENSION POWER)
              </span>
            </div>
            <span className="font-pixel text-xs text-[#ff9900]">
              {trafficStats.tensionPoints}%
            </span>
          </div>

          {/* TP Progress Bar */}
          <div className="mt-2.5 w-full bg-[#151a38] h-3.5 rounded border border-[#ff9900]/40 overflow-hidden relative">
            <div
              className="h-full bg-gradient-to-r from-[#ff6600] to-[#ffcc00] transition-all duration-300 shadow-[0_0_10px_#ff9900]"
              style={{ width: `${trafficStats.tensionPoints}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center text-[9px] font-mono font-bold text-black/80">
              TUNNEL THROUGHPUT
            </div>
          </div>
          <p className="text-[10px] font-mono text-[#7b8bbd] mt-1 flex justify-between">
            <span>Uptime: {formatUptime(trafficStats.uptimeSeconds)}</span>
            <span>Jitter: {trafficStats.jitter}ms</span>
          </p>
        </div>

        {/* HP Health & Latency Bar */}
        <div className="bg-[#0b0e20] border-2 border-[#1c234a] rounded-lg p-3 relative overflow-hidden flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Radio className="w-4 h-4 text-[#00ff66]" />
              <span className="font-pixel text-[10px] text-[#00ff66] tracking-wider">
                HP (PING & HEALTH)
              </span>
            </div>
            <span className="font-pixel text-xs text-[#00ff66]">
              {trafficStats.healthPoints}/100
            </span>
          </div>

          {/* HP Progress Bar */}
          <div className="mt-2.5 w-full bg-[#151a38] h-3.5 rounded border border-[#00ff66]/40 overflow-hidden relative">
            <div
              className="h-full bg-gradient-to-r from-[#00b050] to-[#00ff66] transition-all duration-300 shadow-[0_0_10px_#00ff66]"
              style={{ width: `${trafficStats.healthPoints}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center text-[9px] font-mono font-bold text-black/80">
              LATENCY: {connectionState === 'CONNECTED' ? `${trafficStats.ping} ms` : 'IDLE'}
            </div>
          </div>
          <p className="text-[10px] font-mono text-[#7b8bbd] mt-1 flex justify-between">
            <span>Packet Loss: {trafficStats.packetLoss}%</span>
            <span>Zero-RTT: Active</span>
          </p>
        </div>

        {/* Current Gateway Card with Change button */}
        <div 
          onClick={onOpenServers}
          className="bg-[#0b0e20] border-2 border-[#1c234a] hover:border-[#00f0ff]/60 transition-all rounded-lg p-3 cursor-pointer group flex flex-col justify-between shadow-lg"
          title="Click to select different Dark World Gateway"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xl">{currentServer.flag}</span>
              <div>
                <div className="text-xs font-bold text-white group-hover:text-[#00f0ff] transition-colors flex items-center gap-1">
                  <span>{currentServer.name.split('(')[0]}</span>
                  <ChevronRight className="w-3 h-3 text-[#7b8bbd] group-hover:translate-x-0.5 transition-transform" />
                </div>
                <div className="text-[10px] font-mono text-[#7e8dbd]">
                  {currentServer.city}, {currentServer.country}
                </div>
              </div>
            </div>
            <span className="font-mono text-xs font-bold text-[#00ff66] bg-[#121836] px-1.5 py-0.5 rounded border border-[#222d5c]">
              {currentServer.ping}ms
            </span>
          </div>

          <div className="flex items-center gap-1.5 mt-2">
            <span className="px-1.5 py-0.5 bg-[#172045] rounded text-[9px] font-mono text-[#00f0ff] border border-[#00f0ff]/30">
              {currentServer.protocol.replace(/_/g, ' ')}
            </span>
            <span className="px-1.5 py-0.5 bg-[#172045] rounded text-[9px] font-mono text-[#a5b4fc] border border-[#3b497e]">
              Load: {currentServer.load}%
            </span>
          </div>
        </div>
      </div>

      {/* Center Arena: Soul Core + Live Stats Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Soul Core Arena */}
        <div className="lg:col-span-7 bg-[#080a18] border-2 border-[#1c244c] rounded-xl p-4 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl">
          {/* Cyber scanline overlay */}
          <div className="absolute inset-0 scanlines opacity-40 pointer-events-none" />

          {/* Top arena badges */}
          <div className="w-full flex items-center justify-between text-xs z-10 mb-2">
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-[#101530] border border-[#252f5c] text-[10px] font-mono text-[#9bb0e8]">
              <Cpu className="w-3 h-3 text-[#00f0ff]" />
              <span>Aether v1.8.0 Engine</span>
            </div>
            <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-[#101530] border border-[#252f5c] text-[10px] font-mono text-[#00ff66]">
              <ShieldCheck className="w-3 h-3" />
              <span>Wintun TUN Ready</span>
            </div>
          </div>

          {/* Interactive Soul Heart */}
          <div className="my-2 z-10">
            <SoulHeart
              connectionState={connectionState}
              soulColor={soulColor}
              tensionPoints={trafficStats.tensionPoints}
              onClick={onToggleConnect}
            />
          </div>

          {/* Real-time Bandwidth Waveform Canvas */}
          <div className="w-full mt-3 z-10 bg-[#060814] border border-[#1b2347] rounded-lg p-2">
            <div className="flex items-center justify-between text-[10px] font-mono text-[#8292c4] mb-1">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-[#00f0ff] animate-pulse" />
                Live Tunnel Flow
              </span>
              <span>{formatSpeed(trafficStats.downloadSpeed + trafficStats.uploadSpeed)}</span>
            </div>
            <canvas
              ref={canvasRef}
              width={480}
              height={70}
              className="w-full h-[70px] rounded bg-[#03050c]"
            />
          </div>
        </div>

        {/* Right Column: Speedometers, Security Status, and Quick Tun Controls */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          {/* Download & Upload Speed Cards */}
          <div className="grid grid-cols-2 gap-3">
            {/* Download Speed */}
            <div className="bg-[#0b0e20] border-2 border-[#1c234a] rounded-lg p-3 shadow-lg">
              <div className="flex items-center gap-1 text-[10px] font-mono text-[#8b99c7]">
                <ArrowDown className="w-3.5 h-3.5 text-[#00f0ff]" />
                <span>DOWNLOAD</span>
              </div>
              <div className="text-base sm:text-lg font-bold font-mono text-white mt-1 text-[#00f0ff]">
                {formatSpeed(trafficStats.downloadSpeed)}
              </div>
              <div className="text-[10px] font-mono text-[#6c7ca8] mt-0.5">
                Total: {formatBytes(trafficStats.totalDownloaded)}
              </div>
            </div>

            {/* Upload Speed */}
            <div className="bg-[#0b0e20] border-2 border-[#1c234a] rounded-lg p-3 shadow-lg">
              <div className="flex items-center gap-1 text-[10px] font-mono text-[#8b99c7]">
                <ArrowUp className="w-3.5 h-3.5 text-[#ff007f]" />
                <span>UPLOAD</span>
              </div>
              <div className="text-base sm:text-lg font-bold font-mono text-white mt-1 text-[#ff007f]">
                {formatSpeed(trafficStats.uploadSpeed)}
              </div>
              <div className="text-[10px] font-mono text-[#6c7ca8] mt-0.5">
                Total: {formatBytes(trafficStats.totalUploaded)}
              </div>
            </div>
          </div>

          {/* Security & TUN Mode Feature Cards */}
          <div className="bg-[#0b0e20] border-2 border-[#1c234a] rounded-lg p-3 space-y-2.5 shadow-lg">
            <div className="flex items-center justify-between border-b border-[#1c254d] pb-1.5">
              <span className="font-pixel text-[10px] text-white flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-[#00f0ff]" />
                TUN & DPI PROTECTION
              </span>
              <span className="text-[9px] font-mono text-[#00ff66]">ACTIVE</span>
            </div>

            {/* Feature 1: Wintun Adapter */}
            <div 
              onClick={onOpenTun}
              className="flex items-center justify-between p-2 rounded bg-[#10142e] border border-[#212c59] hover:border-[#00f0ff]/50 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#00f0ff]" />
                <div>
                  <div className="text-[11px] font-bold text-white">Wintun Adapter Mode</div>
                  <div className="text-[9px] font-mono text-[#7b8cb8]">{tunConfig.adapterName} • {tunConfig.virtualIp}</div>
                </div>
              </div>
              <span className="px-1.5 py-0.5 rounded bg-[#1b2552] text-[9px] font-mono text-[#00f0ff]">
                CONFIG
              </span>
            </div>

            {/* Feature 2: TLS ClientHello Split */}
            <div 
              onClick={onOpenDpi}
              className="flex items-center justify-between p-2 rounded bg-[#10142e] border border-[#212c59] hover:border-[#ffe600]/50 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#ffe600]" />
                <div>
                  <div className="text-[11px] font-bold text-white">TLS Fragmentation</div>
                  <div className="text-[9px] font-mono text-[#7b8cb8]">Split [{dpiConfig.fragMin}-{dpiConfig.fragMax} bytes] • Anti-SNI</div>
                </div>
              </div>
              <span className="px-1.5 py-0.5 rounded bg-[#2b2714] text-[9px] font-mono text-[#ffe600]">
                TUNE
              </span>
            </div>

            {/* Feature 3: DNS Leak & Kill Switch */}
            <div className="flex items-center justify-between p-2 rounded bg-[#10142e] border border-[#212c59]">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#00ff66]" />
                <div>
                  <div className="text-[11px] font-bold text-white">Zero Leak Kill Switch</div>
                  <div className="text-[9px] font-mono text-[#7b8cb8]">DNS: 1.1.1.1 (DoH) • LAN Bypassed</div>
                </div>
              </div>
              <span className="w-2 h-2 rounded-full bg-[#00ff66] shadow-[0_0_6px_#00ff66]" />
            </div>

            {/* Feature 4: Windows 1-Click Quick Launcher Banner */}
            <div 
              onClick={onOpenQuickSetup}
              className="flex items-center justify-between p-2 rounded bg-gradient-to-r from-[#00f0ff]/10 to-[#a855f7]/10 border border-[#00f0ff]/40 hover:border-[#00f0ff] transition-all cursor-pointer shadow-[0_0_10px_rgba(0,240,255,0.15)]"
            >
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-[#00f0ff]" />
                <div>
                  <div className="text-[11px] font-bold text-[#00f0ff]">Use on Windows (1-Click)</div>
                  <div className="text-[9px] font-mono text-[#8fa3d6]">Export .bat script or sing-box JSON</div>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded bg-[#00f0ff] text-black font-pixel text-[9px] shadow-[0_0_8px_rgba(0,240,255,0.5)]">
                EXPORT
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Deltarune Dialogue Box at Bottom */}
      <div 
        id="deltarune-dialogue-box"
        onClick={handleNextQuote}
        className="w-full deltarune-box rounded-lg p-3.5 cursor-pointer relative transition-transform hover:scale-[1.005] select-none"
        title="Click to hear another Dark World thought!"
      >
        <div className="flex items-start gap-3">
          {/* Character Avatar Box */}
          <div 
            className="w-12 h-12 rounded border-2 border-white bg-[#0b0e24] flex items-center justify-center text-2xl shrink-0 shadow-[0_0_8px_rgba(255,255,255,0.4)]"
            style={{ borderColor: currentQuote.color }}
          >
            {currentQuote.avatar}
          </div>

          {/* Dialogue Text */}
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <span 
                className="font-pixel text-[11px] uppercase tracking-wider"
                style={{ color: currentQuote.color }}
              >
                * {currentQuote.speaker}
              </span>
              <span className="text-[9px] font-mono text-[#7a88b5] flex items-center gap-1">
                <MessageCircle className="w-3 h-3" />
                Click for next tip
              </span>
            </div>
            <p className="font-mono text-xs text-[#f0f4ff] mt-1.5 leading-relaxed min-h-[36px]">
              "{displayedText}"
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
