import React from 'react';
import { ConnectionState, SoulColor } from '../types/vpn';
import { playSound } from '../utils/audio';

export type ActiveTab = 'DASHBOARD' | 'TUN_SETTINGS' | 'DPI_SETTINGS' | 'SERVERS' | 'ROUTING' | 'LOGS' | 'QUICK_SETUP';

interface BattleMenuBarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  connectionState: ConnectionState;
  onToggleConnect: () => void;
  soulColor: SoulColor;
}

export const BattleMenuBar: React.FC<BattleMenuBarProps> = ({
  activeTab,
  onSelectTab,
  connectionState,
  onToggleConnect,
  soulColor
}) => {
  const [hoveredButton, setHoveredButton] = React.useState<string | null>(null);

  const getSoulHex = (color: SoulColor) => {
    switch (color) {
      case 'RED': return '#ff2a2a';
      case 'CYAN': return '#00e5ff';
      case 'YELLOW': return '#ffe600';
      case 'GREEN': return '#00ff66';
    }
  };

  const isConnected = connectionState === 'CONNECTED';
  const isConnecting = connectionState !== 'CONNECTED' && connectionState !== 'DISCONNECTED';

  const menuItems = [
    {
      id: 'FIGHT',
      label: isConnected ? 'DISCONNECT' : isConnecting ? 'CANCEL' : 'FIGHT (CONNECT)',
      icon: '⚔️',
      color: '#ff6600',
      action: () => {
        onToggleConnect();
      },
      isAction: true,
      active: isConnected
    },
    {
      id: 'ACT',
      label: 'ACT (TUN MODE)',
      icon: '🛡️',
      color: '#00f0ff',
      tab: 'TUN_SETTINGS' as ActiveTab
    },
    {
      id: 'ITEM',
      label: 'ITEM (DPI & PROTOCOL)',
      icon: '📦',
      color: '#ffe600',
      tab: 'DPI_SETTINGS' as ActiveTab
    },
    {
      id: 'SERVERS',
      label: 'GATEWAYS (SERVERS)',
      icon: '🌌',
      color: '#a855f7',
      tab: 'SERVERS' as ActiveTab
    },
    {
      id: 'MERCY',
      label: 'SPARE (ROUTING)',
      icon: '🌟',
      color: '#ff007f',
      tab: 'ROUTING' as ActiveTab
    },
    {
      id: 'LOGS',
      label: 'LOGS (CONSOLE)',
      icon: '📜',
      color: '#00ff66',
      tab: 'LOGS' as ActiveTab
    },
    {
      id: 'SETUP',
      label: 'WINDOWS EXPORT (1-CLICK)',
      icon: '⚡',
      color: '#00f0ff',
      tab: 'QUICK_SETUP' as ActiveTab
    }
  ];

  return (
    <nav
      id="deltarune-battle-menu"
      className="w-full bg-[#060812] border-t-2 border-[#1e2547] px-3 py-2 select-none"
    >
      <div className="max-w-6xl mx-auto flex items-center justify-center flex-wrap gap-2 md:gap-3">
        {menuItems.map((item) => {
          const isItemActive = item.tab ? activeTab === item.tab : item.active;
          const isHovered = hoveredButton === item.id;

          return (
            <button
              key={item.id}
              id={`battle-btn-${item.id.toLowerCase()}`}
              onMouseEnter={() => {
                setHoveredButton(item.id);
                playSound.cursor();
              }}
              onMouseLeave={() => setHoveredButton(null)}
              onClick={() => {
                if (item.action) {
                  item.action();
                } else if (item.tab) {
                  onSelectTab(activeTab === item.tab ? 'DASHBOARD' : item.tab);
                  playSound.select();
                }
              }}
              className={`relative flex items-center gap-2 px-3 py-2 rounded border-2 transition-all duration-150 font-pixel text-[10px] sm:text-xs uppercase tracking-wider ${
                isItemActive
                  ? 'border-[#ffffff] bg-[#141a38] text-white shadow-[0_0_12px_rgba(255,255,255,0.4)]'
                  : 'border-[#222b54] bg-[#0c0f24] text-[#93a3d6] hover:border-[#5263a3] hover:text-white hover:bg-[#121736]'
              }`}
              style={{
                borderColor: isItemActive ? item.color : undefined,
                boxShadow: isItemActive ? `0 0 14px ${item.color}66` : undefined
              }}
            >
              {/* Soul Heart Cursor on hover or active */}
              {(isHovered || isItemActive) && (
                <svg
                  width="12"
                  height="12"
                  viewBox="0 0 24 24"
                  fill={getSoulHex(soulColor)}
                  className="animate-pulse drop-shadow-[0_0_4px_currentColor] shrink-0"
                >
                  <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                </svg>
              )}

              <span>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
