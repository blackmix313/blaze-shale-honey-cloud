import React from 'react';
import { Volume2, VolumeX, Shield, Sparkles, Minus, Square, X, Laptop, Download } from 'lucide-react';
import { ConnectionState, SoulColor } from '../types/vpn';
import { playSound, isSoundEnabled, setSoundEnabled } from '../utils/audio';

interface TitleBarProps {
  connectionState: ConnectionState;
  soulColor: SoulColor;
  onSoulColorChange: (color: SoulColor) => void;
  onMinimize: () => void;
  onMaximize: () => void;
  onClose: () => void;
  showTraySim: boolean;
  onToggleTraySim: () => void;
  onOpenQuickSetup: () => void;
}

export const TitleBar: React.FC<TitleBarProps> = ({
  connectionState,
  soulColor,
  onSoulColorChange,
  onMinimize,
  onMaximize,
  onClose,
  showTraySim,
  onToggleTraySim,
  onOpenQuickSetup
}) => {
  const [soundOn, setSoundOn] = React.useState(isSoundEnabled());

  const handleSoundToggle = () => {
    const next = !soundOn;
    setSoundOn(next);
    setSoundEnabled(next);
    if (next) playSound.select();
  };

  const getSoulHex = (color: SoulColor) => {
    switch (color) {
      case 'RED': return '#ff2a2a';
      case 'CYAN': return '#00e5ff';
      case 'YELLOW': return '#ffe600';
      case 'GREEN': return '#00ff66';
    }
  };

  return (
    <header
      id="windows-titlebar"
      className="h-10 bg-[#090b16] border-b border-[#222a52] flex items-center justify-between px-3 select-none z-50 text-xs"
    >
      {/* Left: App Title & Status */}
      <div className="flex items-center gap-2.5">
        {/* Soul Mini Icon */}
        <div 
          className="relative cursor-pointer transition-transform hover:scale-125"
          onClick={() => {
            const colors: SoulColor[] = ['RED', 'CYAN', 'YELLOW', 'GREEN'];
            const nextIdx = (colors.indexOf(soulColor) + 1) % colors.length;
            onSoulColorChange(colors[nextIdx]);
            playSound.cursor();
          }}
          title="Click to cycle SOUL power mode"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill={getSoulHex(soulColor)} className="drop-shadow-[0_0_6px_currentColor]">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
          </svg>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-pixel text-[10px] text-[#00f0ff] tracking-wider uppercase">
            Aether
          </span>
          <span className="text-[#6977ad] font-mono">v1.8.0</span>
          <span className="hidden sm:inline-block px-1.5 py-0.5 rounded bg-[#131833] border border-[#2b3566] text-[9px] font-mono text-[#a5b4fc]">
            TUN: Wintun Layer-3
          </span>
        </div>

        {/* Live Status indicator */}
        <div className="flex items-center gap-1.5 ml-2">
          <div className={`w-2 h-2 rounded-full ${
            connectionState === 'CONNECTED' 
              ? 'bg-[#00ff66] shadow-[0_0_8px_#00ff66]' 
              : connectionState === 'DISCONNECTED' 
              ? 'bg-[#626d91]' 
              : 'bg-[#ffe600] animate-ping'
          }`} />
          <span className="text-[10px] font-mono uppercase tracking-wider text-[#9aa7d4]">
            {connectionState}
          </span>
        </div>
      </div>

      {/* Right: Controls, Sound, Soul Picker & Windows Chrome */}
      <div className="flex items-center gap-2">
        {/* Soul Mode Switcher */}
        <div className="hidden md:flex items-center gap-1 px-2 py-0.5 bg-[#121630] border border-[#242d5e] rounded">
          <Sparkles className="w-3 h-3 text-[#ffe600]" />
          <span className="text-[9px] font-mono text-[#8b99c7]">SOUL:</span>
          {(['RED', 'CYAN', 'YELLOW', 'GREEN'] as SoulColor[]).map((c) => (
            <button
              key={c}
              id={`soul-btn-${c.toLowerCase()}`}
              onClick={() => {
                onSoulColorChange(c);
                playSound.select();
              }}
              className={`w-2.5 h-2.5 rounded-full transition-all ${
                soulColor === c ? 'scale-125 ring-1 ring-white shadow-[0_0_6px_currentColor]' : 'opacity-40 hover:opacity-100'
              }`}
              style={{ backgroundColor: getSoulHex(c) }}
              title={`SOUL: ${c}`}
            />
          ))}
        </div>

        {/* Windows Export Quick Setup */}
        <button
          id="export-windows-btn"
          onClick={() => {
            onOpenQuickSetup();
            playSound.select();
          }}
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-mono bg-gradient-to-r from-[#00f0ff]/20 to-[#a855f7]/20 border border-[#00f0ff]/50 text-[#00f0ff] hover:text-white hover:border-[#00f0ff] transition-all shadow-[0_0_8px_rgba(0,240,255,0.2)]"
          title="Download 1-Click Windows .BAT or Sing-box Config"
        >
          <Download className="w-3 h-3 text-[#00f0ff]" />
          <span className="font-bold">Windows Setup</span>
        </button>

        {/* Windows Tray Sim Toggle */}
        <button
          id="toggle-tray-sim-btn"
          onClick={() => {
            onToggleTraySim();
            playSound.cursor();
          }}
          className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-mono transition-colors ${
            showTraySim ? 'bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/50' : 'bg-[#121630] text-[#7d8cb8] hover:text-white border border-[#242d5e]'
          }`}
          title="Toggle Windows System Tray simulation"
        >
          <Laptop className="w-3 h-3" />
          <span className="hidden lg:inline">Tray Sim</span>
        </button>

        {/* Sound Toggle */}
        <button
          id="sound-toggle-btn"
          onClick={handleSoundToggle}
          className="p-1 rounded text-[#7d8cb8] hover:text-[#00f0ff] hover:bg-[#151b3b] transition-colors"
          title={soundOn ? 'Sound Effects Enabled' : 'Sound Effects Muted'}
        >
          {soundOn ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5 text-red-400" />}
        </button>

        {/* Windows Window Buttons */}
        <div className="flex items-center ml-2 border-l border-[#222a52] pl-2">
          <button
            id="win-minimize-btn"
            onClick={() => {
              onMinimize();
              playSound.cursor();
            }}
            className="w-7 h-7 flex items-center justify-center text-[#8b99c7] hover:bg-[#1a2147] hover:text-white transition-colors"
            title="Minimize to Tray"
          >
            <Minus className="w-3 h-3" />
          </button>
          <button
            id="win-maximize-btn"
            onClick={() => {
              onMaximize();
              playSound.cursor();
            }}
            className="w-7 h-7 flex items-center justify-center text-[#8b99c7] hover:bg-[#1a2147] hover:text-white transition-colors"
            title="Maximize"
          >
            <Square className="w-2.5 h-2.5" />
          </button>
          <button
            id="win-close-btn"
            onClick={() => {
              onClose();
              playSound.cancel();
            }}
            className="w-7 h-7 flex items-center justify-center text-[#8b99c7] hover:bg-[#e81123] hover:text-white transition-colors"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
