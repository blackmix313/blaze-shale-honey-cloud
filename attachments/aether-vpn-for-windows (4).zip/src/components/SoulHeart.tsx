import React from 'react';
import { ConnectionState, SoulColor } from '../types/vpn';
import { playSound } from '../utils/audio';

interface SoulHeartProps {
  connectionState: ConnectionState;
  soulColor: SoulColor;
  tensionPoints: number; // 0 to 100
  onClick: () => void;
}

export const SoulHeart: React.FC<SoulHeartProps> = ({
  connectionState,
  soulColor,
  tensionPoints,
  onClick
}) => {
  const getSoulConfig = (color: SoulColor) => {
    switch (color) {
      case 'RED':
        return {
          fill: '#ff2a2a',
          glow: 'rgba(255, 42, 42, 0.65)',
          title: 'DETERMINATION',
          sub: 'Kris SOUL • Standard Mode'
        };
      case 'CYAN':
        return {
          fill: '#00e5ff',
          glow: 'rgba(0, 229, 255, 0.65)',
          title: 'PATIENCE',
          sub: 'Low-Jitter WireGuard Stream'
        };
      case 'YELLOW':
        return {
          fill: '#ffe600',
          glow: 'rgba(255, 230, 0, 0.65)',
          title: 'JUSTICE',
          sub: 'Aggressive Anti-DPI Split'
        };
      case 'GREEN':
        return {
          fill: '#00ff66',
          glow: 'rgba(0, 255, 102, 0.65)',
          title: 'KINDNESS',
          sub: 'Zero DNS Leak Shield'
        };
    }
  };

  const currentSoul = getSoulConfig(soulColor);
  const isConnected = connectionState === 'CONNECTED';
  const isConnecting = connectionState !== 'CONNECTED' && connectionState !== 'DISCONNECTED';

  return (
    <div className="flex flex-col items-center justify-center select-none py-2">
      {/* Soul Aura Container */}
      <div className="relative group flex items-center justify-center">
        {/* Background Orbit Ring */}
        <div 
          className={`absolute w-44 h-44 rounded-full border border-dashed transition-all duration-700 ${
            isConnected
              ? 'border-[#00f0ff]/40 animate-[spin_12s_linear_infinite]'
              : isConnecting
              ? 'border-[#ffe600]/50 animate-[spin_3s_linear_infinite]'
              : 'border-[#293563]/40'
          }`}
        />

        {/* Second Counter-Orbit Ring */}
        <div 
          className={`absolute w-36 h-36 rounded-full border transition-all duration-700 ${
            isConnected
              ? 'border-[#ff007f]/30 animate-[spin_8s_linear_infinite_reverse]'
              : isConnecting
              ? 'border-[#00f0ff]/40 animate-[spin_2s_linear_infinite_reverse]'
              : 'border-transparent'
          }`}
        />

        {/* Ambient Radial Glow */}
        <div 
          className="absolute w-28 h-28 rounded-full blur-xl transition-all duration-500 opacity-60 group-hover:opacity-100"
          style={{
            backgroundColor: isConnected ? currentSoul.fill : isConnecting ? '#ffe600' : '#1a2347'
          }}
        />

        {/* Tension Points (TP) Energy Ring */}
        {isConnected && (
          <svg className="absolute w-48 h-48 -rotate-90 pointer-events-none">
            <circle
              cx="96"
              cy="96"
              r="86"
              fill="transparent"
              stroke="#212952"
              strokeWidth="3"
            />
            <circle
              cx="96"
              cy="96"
              r="86"
              fill="transparent"
              stroke="#ff9900"
              strokeWidth="4"
              strokeDasharray={540}
              strokeDashoffset={540 - (540 * tensionPoints) / 100}
              strokeLinecap="round"
              className="transition-all duration-300 drop-shadow-[0_0_8px_#ff9900]"
            />
          </svg>
        )}

        {/* The Clickable Soul Heart Core */}
        <button
          id="main-soul-connect-btn"
          onClick={() => {
            onClick();
            playSound.heartbeat();
          }}
          className={`relative z-10 p-6 rounded-full transition-transform duration-200 active:scale-95 focus:outline-none ${
            isConnected ? 'animate-soul-pulse' : isConnecting ? 'animate-bounce' : 'hover:scale-110'
          }`}
          title={isConnected ? 'Click to Disconnect Tunnel' : 'Click to Establish Wintun VPN Tunnel'}
        >
          {/* Pixel Heart SVG */}
          <svg
            width="68"
            height="68"
            viewBox="0 0 24 24"
            className="transition-all duration-300 drop-shadow-[0_0_16px_var(--glow)]"
            style={{
              filter: `drop-shadow(0 0 ${isConnected ? '18px' : '8px'} ${
                isConnected ? currentSoul.fill : isConnecting ? '#ffe600' : '#495788'
              })`
            }}
          >
            <path
              d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
              fill={isConnected ? currentSoul.fill : isConnecting ? '#ffe600' : '#2b3663'}
              stroke="#ffffff"
              strokeWidth={isConnected ? "0.8" : "0.5"}
            />
          </svg>
        </button>
      </div>

      {/* Soul State Text */}
      <div className="mt-3 text-center">
        <div className="flex items-center justify-center gap-1.5">
          <span 
            className="font-pixel text-xs tracking-wider"
            style={{ color: isConnected ? currentSoul.fill : '#7b8ab8' }}
          >
            {isConnected ? 'TUNNEL ACTIVE' : isConnecting ? 'SYNCHRONIZING...' : 'STANDBY'}
          </span>
        </div>
        <p className="text-[11px] font-mono text-[#8a99c9] mt-0.5">
          {isConnected 
            ? `Wintun Adapter [Layer-3] • ${currentSoul.title}` 
            : isConnecting 
            ? 'Fragmenting TLS ClientHello...' 
            : 'Press Soul or [FIGHT] to engage Aether VPN'}
        </p>
      </div>
    </div>
  );
};
