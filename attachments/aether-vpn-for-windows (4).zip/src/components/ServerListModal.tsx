import React, { useState } from 'react';
import { ServerNode, VpnProtocol } from '../types/vpn';
import { playSound } from '../utils/audio';
import { 
  Globe2, 
  X, 
  Check, 
  Search, 
  Zap, 
  Star, 
  RefreshCw, 
  Plus, 
  Radio, 
  ShieldCheck,
  Flame
} from 'lucide-react';

interface ServerListModalProps {
  servers: ServerNode[];
  selectedServer: ServerNode;
  onSelectServer: (server: ServerNode) => void;
  onClose: () => void;
}

export const ServerListModal: React.FC<ServerListModalProps> = ({
  servers: initialServers,
  selectedServer,
  onSelectServer,
  onClose
}) => {
  const [servers, setServers] = useState<ServerNode[]>(initialServers);
  const [searchTerm, setSearchTerm] = useState('');
  const [protocolFilter, setProtocolFilter] = useState<string>('ALL');
  const [isPinging, setIsPinging] = useState(false);
  const [showAddCustom, setShowAddCustom] = useState(false);

  // Custom node state
  const [customName, setCustomName] = useState('');
  const [customHost, setCustomHost] = useState('');
  const [customPort, setCustomPort] = useState(443);
  const [customProto, setCustomProto] = useState<VpnProtocol>('MASQUE_H3');

  const handlePingAll = () => {
    setIsPinging(true);
    playSound.cursor();
    setTimeout(() => {
      setServers((prev) =>
        prev.map((s) => {
          const delta = Math.floor(Math.random() * 12) - 5;
          return {
            ...s,
            ping: Math.max(18, s.ping + delta)
          };
        })
      );
      setIsPinging(false);
      playSound.select();
    }, 800);
  };

  const handleToggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setServers((prev) =>
      prev.map((s) => (s.id === id ? { ...s, isFavorite: !s.isFavorite } : s))
    );
    playSound.select();
  };

  const handleAddCustomServer = () => {
    if (!customHost.trim()) return;
    const newNode: ServerNode = {
      id: `custom-${Date.now()}`,
      name: customName.trim() || `Custom Node (${customHost.trim()})`,
      darkWorldZone: 'Custom Fountain',
      country: 'Dark Sanctuary',
      city: 'Encrypted Relay',
      flag: '🛡️',
      ping: Math.floor(Math.random() * 30) + 25,
      protocol: customProto,
      serverAddress: customHost.trim(),
      port: Number(customPort) || 443,
      load: 10,
      isFavorite: true,
      features: ['Custom Gateway', 'Wintun Layer 3', 'User Configured']
    };
    setServers([newNode, ...servers]);
    setShowAddCustom(false);
    setCustomName('');
    setCustomHost('');
    playSound.connected();
  };

  const filteredServers = servers.filter((s) => {
    const matchSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.country.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.darkWorldZone.toLowerCase().includes(searchTerm.toLowerCase());

    const matchProtocol =
      protocolFilter === 'ALL'
        ? true
        : protocolFilter === 'FAVORITES'
        ? s.isFavorite
        : s.protocol === protocolFilter;

    return matchSearch && matchProtocol;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#090c1e] border-2 border-[#a855f7] rounded-xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-[0_0_25px_rgba(168,85,247,0.25)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#0d122c] border-b border-[#1c244c]">
          <div className="flex items-center gap-2">
            <Globe2 className="w-5 h-5 text-[#a855f7]" />
            <h2 className="font-pixel text-xs text-white uppercase tracking-wider">
              Dark World Fountain Gateways & Edge Nodes
            </h2>
          </div>
          <button
            onClick={() => {
              onClose();
              playSound.cancel();
            }}
            className="p-1 rounded text-[#7b8bbd] hover:text-white hover:bg-[#1a2347] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Toolbar: Search, Filters & Ping button */}
        <div className="p-3 bg-[#0c1026] border-b border-[#1c254e] flex flex-wrap items-center justify-between gap-2">
          {/* Search Box */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-[#6c7ca6] absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search Gateways, Cities, Dark World Zones..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#111736] border border-[#212d59] rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-[#586791] outline-none focus:border-[#a855f7]"
            />
          </div>

          <div className="flex items-center gap-1.5">
            {/* Ping Test Button */}
            <button
              onClick={handlePingAll}
              disabled={isPinging}
              className="px-2.5 py-1.5 bg-[#171f45] hover:bg-[#25326b] border border-[#2b3a7a] rounded text-[10px] font-mono text-[#00f0ff] flex items-center gap-1 transition-colors"
              title="Test Latency to all servers"
            >
              <RefreshCw className={`w-3 h-3 ${isPinging ? 'animate-spin' : ''}`} />
              <span>{isPinging ? 'Pinging...' : 'Ping All'}</span>
            </button>

            {/* Custom Node Add button */}
            <button
              onClick={() => {
                setShowAddCustom(!showAddCustom);
                playSound.select();
              }}
              className="px-2.5 py-1.5 bg-[#26153d] hover:bg-[#3d1e63] border border-[#582e8f] rounded text-[10px] font-mono text-[#c084fc] flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3 h-3" />
              <span>Custom Node</span>
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="px-3 py-2 bg-[#0a0d20] border-b border-[#182042] flex items-center gap-1.5 overflow-x-auto text-[10px] font-mono">
          {[
            { id: 'ALL', label: 'All Gateways' },
            { id: 'FAVORITES', label: '★ Favorites' },
            { id: 'MASQUE_H3', label: 'MASQUE (HTTP/3)' },
            { id: 'NESTED_WIREGUARD_MASQUE', label: 'Nested WireGuard' },
            { id: 'WIREGUARD', label: 'WireGuard-NT' },
            { id: 'VLESS_REALITY', label: 'VLESS Reality' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setProtocolFilter(tab.id);
                playSound.cursor();
              }}
              className={`px-2.5 py-1 rounded whitespace-nowrap transition-colors ${
                protocolFilter === tab.id
                  ? 'bg-[#a855f7] text-white font-bold shadow-[0_0_8px_rgba(168,85,247,0.4)]'
                  : 'bg-[#121633] text-[#7d8fb8] hover:text-white hover:bg-[#1c234f]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Custom Node Input Drawer */}
        {showAddCustom && (
          <div className="p-3 bg-[#130f24] border-b border-[#3b1d5c] space-y-2 text-xs font-mono">
            <div className="font-pixel text-[9px] text-[#c084fc] uppercase">Add Custom Aether / MASQUE Endpoint</div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                placeholder="Name (e.g. My Private Relay)"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                className="bg-[#1c1433] border border-[#3b2266] rounded px-2 py-1 text-white text-[11px] outline-none"
              />
              <input
                type="text"
                placeholder="Host (e.g. vpn.myfountain.net)"
                value={customHost}
                onChange={(e) => setCustomHost(e.target.value)}
                className="bg-[#1c1433] border border-[#3b2266] rounded px-2 py-1 text-white text-[11px] outline-none"
              />
              <select
                value={customProto}
                onChange={(e) => setCustomProto(e.target.value as any)}
                className="bg-[#1c1433] border border-[#3b2266] rounded px-2 py-1 text-white text-[11px] outline-none"
              >
                <option value="MASQUE_H3">MASQUE HTTP/3</option>
                <option value="NESTED_WIREGUARD_MASQUE">Nested WireGuard</option>
                <option value="WIREGUARD">WireGuard-NT</option>
                <option value="VLESS_REALITY">VLESS Reality</option>
              </select>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button
                onClick={() => setShowAddCustom(false)}
                className="px-2 py-1 text-[#8b99c7] hover:text-white text-[10px]"
              >
                Cancel
              </button>
              <button
                onClick={handleAddCustomServer}
                className="px-3 py-1 bg-[#a855f7] hover:bg-[#c084fc] text-white rounded text-[10px] font-bold"
              >
                Save & Connect
              </button>
            </div>
          </div>
        )}

        {/* Server List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {filteredServers.map((server) => {
            const isSelected = selectedServer.id === server.id;

            return (
              <div
                key={server.id}
                onClick={() => {
                  onSelectServer(server);
                  playSound.select();
                }}
                className={`p-3 rounded-lg border-2 transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                  isSelected
                    ? 'border-[#a855f7] bg-[#1a1438] shadow-[0_0_12px_rgba(168,85,247,0.35)]'
                    : 'border-[#1b234a] bg-[#0c1026] hover:border-[#38488a] hover:bg-[#111738]'
                }`}
              >
                {/* Left info */}
                <div className="flex items-start gap-3">
                  <span className="text-2xl">{server.flag}</span>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-xs">{server.name}</span>
                      {isSelected && (
                        <span className="px-1.5 py-0.5 rounded bg-[#a855f7] text-white text-[9px] font-pixel">
                          ACTIVE
                        </span>
                      )}
                    </div>
                    <div className="text-[10px] font-mono text-[#8a9bc9] mt-0.5">
                      {server.city}, {server.country} • <span className="text-[#a855f7]">{server.darkWorldZone}</span>
                    </div>
                    {/* Features badges */}
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      <span className="px-1.5 py-0.5 rounded bg-[#131938] text-[9px] font-mono text-[#00f0ff] border border-[#00f0ff]/30">
                        {server.protocol.replace(/_/g, ' ')}
                      </span>
                      {server.features.slice(0, 2).map((feat, idx) => (
                        <span key={idx} className="px-1.5 py-0.5 rounded bg-[#131938] text-[9px] font-mono text-[#7888b5] border border-[#232f5e]">
                          {feat}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right stats & action */}
                <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#1b234a]">
                  {/* Ping */}
                  <div className="flex items-center gap-1 font-mono text-xs font-bold text-[#00ff66]">
                    <Zap className="w-3.5 h-3.5 text-[#00ff66]" />
                    <span>{server.ping} ms</span>
                  </div>

                  {/* Load Bar */}
                  <div className="w-16 hidden sm:block">
                    <div className="flex justify-between text-[8px] font-mono text-[#6c7ca6] mb-0.5">
                      <span>LOAD</span>
                      <span>{server.load}%</span>
                    </div>
                    <div className="w-full bg-[#182042] h-1.5 rounded overflow-hidden">
                      <div
                        className={`h-full rounded ${
                          server.load > 70 ? 'bg-red-500' : server.load > 40 ? 'bg-amber-400' : 'bg-[#00ff66]'
                        }`}
                        style={{ width: `${server.load}%` }}
                      />
                    </div>
                  </div>

                  {/* Favorite Toggle */}
                  <button
                    type="button"
                    onClick={(e) => handleToggleFavorite(e, server.id)}
                    className={`p-1.5 rounded transition-colors ${
                      server.isFavorite ? 'text-[#ffe600]' : 'text-[#485680] hover:text-white'
                    }`}
                  >
                    <Star className={`w-4 h-4 ${server.isFavorite ? 'fill-[#ffe600]' : ''}`} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#0d122c] border-t border-[#1c244c] flex items-center justify-between">
          <div className="text-[10px] font-mono text-[#7a88b5]">
            Total Gateways: <strong className="text-white">{filteredServers.length}</strong>
          </div>
          <button
            onClick={() => {
              onClose();
              playSound.select();
            }}
            className="px-4 py-1.5 rounded bg-[#a855f7] hover:bg-[#c084fc] text-white text-[10px] font-pixel shadow-[0_0_10px_rgba(168,85,247,0.4)] transition-all"
          >
            SELECT GATEWAY
          </button>
        </div>
      </div>
    </div>
  );
};
