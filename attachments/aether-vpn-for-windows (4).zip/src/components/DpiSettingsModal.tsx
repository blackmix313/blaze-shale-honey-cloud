import React, { useState } from 'react';
import { DpiEvasionConfig } from '../types/vpn';
import { playSound } from '../utils/audio';
import { 
  Sparkles, 
  X, 
  Check, 
  ShieldAlert, 
  Lock, 
  KeyRound, 
  Zap, 
  Sliders, 
  Shuffle, 
  Info,
  Radio
} from 'lucide-react';

interface DpiSettingsModalProps {
  config: DpiEvasionConfig;
  onSave: (config: DpiEvasionConfig) => void;
  onClose: () => void;
}

export const DpiSettingsModal: React.FC<DpiSettingsModalProps> = ({
  config,
  onSave,
  onClose
}) => {
  const [formData, setFormData] = useState<DpiEvasionConfig>({ ...config });
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSave = () => {
    onSave(formData);
    playSound.dpiFragment();
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 600);
  };

  const generateRandomSeed = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_DELTARUNE_AETHER_V180';
    let res = '';
    for (let i = 0; i < 28; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setFormData({ ...formData, obfuscationSeed: res });
    playSound.select();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#090c1e] border-2 border-[#ffe600] rounded-xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-[0_0_25px_rgba(255,230,0,0.25)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#0d122c] border-b border-[#1c244c]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#ffe600]" />
            <h2 className="font-pixel text-xs text-white uppercase tracking-wider">
              ITEM: Aether v1.8.0 DPI Evasion & Protocol Tuner
            </h2>
          </div>
          <button
            onClick={() => {
              onClose();
              playSound.cancel();
            }}
            className="p-1 rounded text-[#7b8bbd] hover:text-white hover:bg-[#1a2347] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs font-mono text-[#d6deff]">
          {/* Info banner */}
          <div className="p-3 bg-[#171609] border border-[#4d4316] rounded-lg flex items-start gap-2.5">
            <ShieldAlert className="w-4 h-4 text-[#ffe600] shrink-0 mt-0.5" />
            <p className="text-[11px] text-[#f2e59e] leading-relaxed">
              Aether v1.8.0 specializes in defeating Deep Packet Inspection (DPI) firewalls, protocol fingerprinting, and SNI blocking via <strong>TLS ClientHello fragmentation</strong> and <strong>MASQUE (HTTP/3 & HTTP/2)</strong> tunnels.
            </p>
          </div>

          {/* Section 1: TLS ClientHello Fragmentation */}
          <div className="space-y-3 bg-[#0b0f26] p-3.5 rounded-lg border border-[#1d2654]">
            <div className="flex items-center justify-between">
              <h3 className="font-pixel text-[10px] text-[#ffe600] uppercase">1. TLS ClientHello Fragmentation</h3>
              <label className="flex items-center gap-2 cursor-pointer">
                <span className="text-[10px] text-[#8fa0cf]">Enable Split</span>
                <input
                  type="checkbox"
                  checked={formData.tlsFragmentation}
                  onChange={(e) => setFormData({ ...formData, tlsFragmentation: e.target.checked })}
                  className="accent-[#ffe600] w-4 h-4 rounded"
                />
              </label>
            </div>

            {formData.tlsFragmentation && (
              <div className="space-y-3 pt-1">
                <div>
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="text-[#8696c7]">Min Fragment Slice:</span>
                    <span className="text-[#ffe600] font-bold">{formData.fragMin} bytes</span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="30"
                    value={formData.fragMin}
                    onChange={(e) => setFormData({ ...formData, fragMin: parseInt(e.target.value) })}
                    className="w-full accent-[#ffe600] cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between text-[11px] mb-1">
                    <span className="text-[#8696c7]">Max Fragment Slice:</span>
                    <span className="text-[#ffe600] font-bold">{formData.fragMax} bytes</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="64"
                    value={formData.fragMax}
                    onChange={(e) => setFormData({ ...formData, fragMax: parseInt(e.target.value) })}
                    className="w-full accent-[#ffe600] cursor-pointer"
                  />
                </div>
                <div className="text-[9px] text-[#697baa]">
                  * Chunks the TLS SNI (Server Name Indication) extension into micro-segments, rendering stateful DPI filters unable to reconstruct target domain names.
                </div>
              </div>
            )}
          </div>

          {/* Section 2: MASQUE Tunnel & Congestion Control */}
          <div className="space-y-3 bg-[#0b0f26] p-3.5 rounded-lg border border-[#1d2654]">
            <h3 className="font-pixel text-[10px] text-[#00f0ff] uppercase">2. MASQUE Protocol & Transport</h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {[
                { id: 'HTTP3', name: 'MASQUE (HTTP/3)', desc: 'QUIC / UDP 0-RTT' },
                { id: 'HTTP2', name: 'MASQUE (HTTP/2)', desc: 'TCP TLS Fallback' },
                { id: 'AUTO', name: 'Auto Discover', desc: 'Fastest Ping Route' }
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    setFormData({ ...formData, masqueVersion: m.id as any });
                    playSound.select();
                  }}
                  className={`p-2.5 rounded border text-left transition-all ${
                    formData.masqueVersion === m.id
                      ? 'border-[#00f0ff] bg-[#141b40] shadow-[0_0_8px_rgba(0,240,255,0.3)]'
                      : 'border-[#1e2752] bg-[#0d122b] hover:border-[#384687]'
                  }`}
                >
                  <div className="font-bold text-white text-[11px]">{m.name}</div>
                  <div className="text-[9px] text-[#7a8bb8] mt-0.5">{m.desc}</div>
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
              <div>
                <label className="text-[10px] text-[#8696c7] block mb-1">Congestion Control Algorithm</label>
                <select
                  value={formData.congestionControl}
                  onChange={(e) => setFormData({ ...formData, congestionControl: e.target.value as any })}
                  className="w-full bg-[#111636] border border-[#232f63] rounded px-2.5 py-1.5 text-white focus:border-[#00f0ff] outline-none"
                >
                  <option value="BBRv3">BBRv3 (Loss Tolerant & High Throughput)</option>
                  <option value="BBR">BBRv1 (Standard Bottleneck Bandwidth)</option>
                  <option value="CUBIC">CUBIC (Standard Linux/Windows TCP)</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-[#8696c7] block mb-1">ALPN Protocol Spoofing</label>
                <select
                  value={formData.alpnSpoofing}
                  onChange={(e) => setFormData({ ...formData, alpnSpoofing: e.target.value as any })}
                  className="w-full bg-[#111636] border border-[#232f63] rounded px-2.5 py-1.5 text-white focus:border-[#00f0ff] outline-none"
                >
                  <option value="h3">h3 (HTTP/3 QUIC)</option>
                  <option value="h2">h2 (HTTP/2 TLS)</option>
                  <option value="http/1.1">http/1.1 (Standard HTTP)</option>
                  <option value="randomized">Randomized Dynamic Spoof</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Obfuscation Key & Traffic Padding */}
          <div className="space-y-3 bg-[#0b0f26] p-3.5 rounded-lg border border-[#1d2654]">
            <h3 className="font-pixel text-[10px] text-[#ff007f] uppercase">3. Obfuscation & Entropy Shield</h3>

            <div>
              <label className="text-[10px] text-[#8696c7] block mb-1">Obfuscation Key / Seed</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={formData.obfuscationSeed}
                  onChange={(e) => setFormData({ ...formData, obfuscationSeed: e.target.value })}
                  className="flex-1 bg-[#111636] border border-[#232f63] rounded px-2.5 py-1.5 text-white focus:border-[#ff007f] outline-none font-mono text-[10px]"
                />
                <button
                  type="button"
                  onClick={generateRandomSeed}
                  className="px-2.5 py-1 bg-[#241738] hover:bg-[#ff007f] hover:text-white rounded text-[10px] text-[#ff007f] border border-[#ff007f]/40 transition-colors flex items-center gap-1"
                  title="Generate Random Entropy Seed"
                >
                  <Shuffle className="w-3 h-3" />
                  Randomize
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mt-2">
              <label className="flex items-center gap-2.5 p-2 rounded bg-[#101533] border border-[#1f2854] cursor-pointer hover:border-[#38488c]">
                <input
                  type="checkbox"
                  checked={formData.noisePadding}
                  onChange={(e) => setFormData({ ...formData, noisePadding: e.target.checked })}
                  className="accent-[#ff007f] w-4 h-4 rounded"
                />
                <div>
                  <div className="font-bold text-white text-[11px]">Dynamic Noise Padding</div>
                  <div className="text-[9px] text-[#7888b5]">Inject random decoy bytes to disguise packet sizes</div>
                </div>
              </label>

              <label className="flex items-center gap-2.5 p-2 rounded bg-[#101533] border border-[#1f2854] cursor-pointer hover:border-[#38488c]">
                <input
                  type="checkbox"
                  checked={formData.zeroRtt}
                  onChange={(e) => setFormData({ ...formData, zeroRtt: e.target.checked })}
                  className="accent-[#ff007f] w-4 h-4 rounded"
                />
                <div>
                  <div className="font-bold text-white text-[11px]">0-RTT Early Handshake</div>
                  <div className="text-[9px] text-[#7888b5]">Send encrypted data on first roundtrip</div>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#0d122c] border-t border-[#1c244c] flex items-center justify-end gap-2">
          <button
            onClick={() => {
              onClose();
              playSound.cancel();
            }}
            className="px-3.5 py-1.5 rounded bg-[#131a3d] hover:bg-[#1d2757] text-[#9aa7d4] text-[10px] font-pixel transition-colors"
          >
            CANCEL
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-1.5 rounded bg-[#ffe600] hover:bg-[#fff066] text-black text-[10px] font-pixel shadow-[0_0_10px_rgba(255,230,0,0.5)] transition-all flex items-center gap-1.5"
          >
            {saveSuccess ? (
              <>
                <Check className="w-3.5 h-3.5" />
                DPI SHIELD ARMED!
              </>
            ) : (
              'SAVE DPI RULES'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
