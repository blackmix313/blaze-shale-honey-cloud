import React from 'react';
import { ServerNode, ConnectionState, SoulColor, TrafficStats } from '../types/vpn';
import { playSound } from '../utils/audio';
import { 
  ShieldCheck, 
  Power, 
  ArrowDown, 
  ArrowUp, 
  Maximize2, 
  X, 
  Radio,
  Sparkles
} from 'lucide-react';

interface WindowsTraySimProps {
  currentServer: ServerNode;
  connectionState: ConnectionState;
  soulColor: SoulColor;
  trafficStats: TrafficStats;
  onToggleConnect: () => void;
  onRestoreWindow: () => void;
  onClose: () => void;
}

export const WindowsTraySim: React.FC<WindowsTraySimProps> = ({
  currentServer,
  connectionState,
  soulColor,
  trafficStats,
  onToggleConnect,
  onRestoreWindow,
  onClose
}) => {
  const isConnected = connectionState === 'CONNECTED';
  const isConnecting = connectionState !== 'CONNECTED' && connectionState !== 'DISCONNECTED';

  const formatSpeed = (bytesPerSec: number) => {
    if (bytesPerSec === 0) return '0 KB/s';
    const mbps = bytesPerSec / (1024 * 1024);
    if (mbps >= 1) return `${mbps.toFixed(1)} MB/s`;
    return `${(bytesPerSec / 1024).toFixed(0)} KB/s`;
  };

  return (
    <div className="fixed bottom-3 right-3 z-50 w-72 bg-[#090d21] border-2 border-[#242f5e] rounded-xl shadow-[0_10px_35px_rgba(0,0,0,0.8)] overflow-hidden font-mono text-xs text-[#dbe3fc] animate-in fade-in slide-in-from-bottom-3 duration-200 select-none">
      {/* Windows Tray Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#0d1430] border-b border-[#1c2650]">
        <div className="flex items-center gap-1.5">
          <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-[#00ff66]' : 'bg-[#627096]'}`} />
          <span className="font-pixel text-[9px] text-[#00f0ff]">Aether Tray</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              onRestoreWindow();
              playSound.select();
            }}
            className="p-1 hover:bg-[#1b2552] rounded text-[#8a99c9] hover:text-white"
            title="Open Window"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              onClose();
              playSound.cancel();
            }}
            className="p-1 hover:bg-[#1b2552] rounded text-[#8a99c9] hover:text-white"
            title="Hide Tray Popup"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Tray Content */}
      <div className="p-3 space-y-2.5 bg-[#090d21]">
        {/* Node info */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">{currentServer.flag}</span>
            <div>
              <div className="font-bold text-white text-[11px] truncate max-w-[130px]">
                {currentServer.name.split('(')[0]}
              </div>
              <div className="text-[9px] text-[#7182b0]">{currentServer.city}</div>
            </div>
          </div>
          <span className="text-[10px] font-bold text-[#00ff66]">{currentServer.ping}ms</span>
        </div>

        {/* Speeds */}
        {isConnected && (
          <div className="grid grid-cols-2 gap-1.5 p-1.5 bg-[#0e1533] rounded border border-[#1d2752] text-[10px]">
            <div className="flex items-center gap-1 text-[#00f0ff]">
              <ArrowDown className="w-3 h-3" />
              <span>{formatSpeed(trafficStats.downloadSpeed)}</span>
            </div>
            <div className="flex items-center gap-1 text-[#ff007f]">
              <ArrowUp className="w-3 h-3" />
              <span>{formatSpeed(trafficStats.uploadSpeed)}</span>
            </div>
          </div>
        )}

        {/* Wintun Status */}
        <div className="flex items-center justify-between text-[9px] text-[#7b8cb8] pt-0.5">
          <span>Adapter: Wintun Layer-3</span>
          <span className="text-[#00ff66]">No Leaks</span>
        </div>

        {/* Quick Action Button */}
        <button
          onClick={() => {
            onToggleConnect();
            playSound.select();
          }}
          className={`w-full py-2 rounded font-pixel text-[10px] flex items-center justify-center gap-1.5 transition-all ${
            isConnected
              ? 'bg-[#181f3d] hover:bg-red-900/60 text-red-300 border border-red-500/40'
              : isConnecting
              ? 'bg-[#ffe600] text-black animate-pulse'
              : 'bg-[#00f0ff] hover:bg-[#5ef5ff] text-black shadow-[0_0_10px_rgba(0,240,255,0.4)]'
          }`}
        >
          <Power className="w-3.5 h-3.5" />
          <span>{isConnected ? 'DISCONNECT' : isConnecting ? 'CONNECTING...' : 'CONNECT TUNNEL'}</span>
        </button>
      </div>
    </div>
  );
};
