import React, { useState } from 'react';
import { 
  Download, 
  Terminal, 
  FileCode, 
  Check, 
  Copy, 
  Laptop, 
  HelpCircle, 
  ArrowRight, 
  ShieldCheck, 
  ExternalLink,
  Layers,
  Sparkles,
  Zap,
  HardDrive
} from 'lucide-react';
import { ServerNode, TunConfig, DpiEvasionConfig } from '../types/vpn';
import { playSound } from '../utils/audio';

interface QuickSetupModalProps {
  currentServer: ServerNode;
  tunConfig: TunConfig;
  dpiConfig: DpiEvasionConfig;
  onClose: () => void;
}

export const QuickSetupModal: React.FC<QuickSetupModalProps> = ({
  currentServer,
  tunConfig,
  dpiConfig,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'DELTARUNE_EXE' | 'ONE_CLICK_BAT' | 'SINGBOX' | 'AETHER_CLI'>('DELTARUNE_EXE');
  const [copied, setCopied] = useState(false);

  // Auto-generated Windows 1-Click PowerShell / Batch Script
  const generateBatScript = () => {
    return `@echo off
:: =========================================================================
::  AETHER v1.8.0 WINDOWS TUN-MODE ONE-CLICK LAUNCHER (DELTARUNE EDITION)
::  Requires Administrator Privileges to load Wintun & configure Routes
:: =========================================================================
NET SESSION >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!] Requesting Administrator elevation...
    powershell -Command "Start-Process '%~0' -Verb RunAs"
    exit /b
)

title Aether v1.8.0 [TUN Mode] - %~1
color 0B
cls
echo  =============================================================
echo     * Kris, our connection is now shielded with TUN mode!
echo     * Gateway: ${currentServer.name} (${currentServer.serverAddress}:${currentServer.port})
echo     * Protocol: ${currentServer.protocol} [Wintun Layer-3]
echo     * TLS Fragmentation: [${dpiConfig.fragMin}-${dpiConfig.fragMax} bytes] (DPI Evasion)
echo  =============================================================
echo.

:: 1. Create working directory
if not exist "%USERPROFILE%\\.aether" mkdir "%USERPROFILE%\\.aether"
cd /d "%USERPROFILE%\\.aether"

:: 2. Download Wintun & Aether binary if missing
if not exist "wintun.dll" (
    echo [*] Downloading high-speed wintun.dll driver...
    powershell -Command "Invoke-WebRequest -Uri 'https://www.wintun.net/builds/wintun-0.14.1.zip' -OutFile 'wintun.zip'; Expand-Archive -Path 'wintun.zip' -DestinationPath 'wintun_temp' -Force; Copy-Item 'wintun_temp\\wintun\\bin\\amd64\\wintun.dll' -Destination '.' -Force; Remove-Item 'wintun.zip','wintun_temp' -Recurse -Force"
)

if not exist "aether-core.exe" (
    echo [*] Downloading Aether v1.8.0 Windows Engine...
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/CluvexStudio/Aether/releases/download/v1.8.0/aether-windows-x86_64.exe' -OutFile 'aether-core.exe'"
)

:: 3. Generate dynamic Aether config.json with current GUI settings
echo [*] Writing TUN routing configuration...
(
echo {
echo   "server": "${currentServer.serverAddress}",
echo   "server_port": ${currentServer.port},
echo   "protocol": "${currentServer.protocol.toLowerCase().replace(/_/g, '-')}",
echo   "tun": {
echo     "enabled": true,
echo     "adapter_name": "${tunConfig.adapterName}",
echo     "virtual_ip": "${tunConfig.virtualIp}",
echo     "mtu": ${tunConfig.mtu},
echo     "strict_route": ${tunConfig.strictRouting},
echo     "fake_dns": ${tunConfig.fakeDns},
echo     "bypass_lan": ${tunConfig.bypassLan},
echo     "kill_switch": ${tunConfig.killSwitch}
echo   },
echo   "dpi_evasion": {
echo     "tls_fragment": ${dpiConfig.tlsFragmentation},
echo     "frag_min": ${dpiConfig.fragMin},
echo     "frag_max": ${dpiConfig.fragMax},
echo     "congestion_control": "${dpiConfig.congestionControl}",
echo     "noise_padding": ${dpiConfig.noisePadding},
echo     "zero_rtt": ${dpiConfig.zeroRtt}
echo   }
echo }
) > config.json

echo.
echo [*] Engaging Wintun Virtual Adapter...
echo [*] All Windows network traffic is now routed through the Dark Fountain!
echo.
echo [PRESS CTRL+C TO DISCONNECT TUNNEL]
echo.

aether-core.exe run --config config.json --tun
pause
`;
  };

  // Auto-generated Sing-box / Clash TUN format configuration
  const generateSingBoxConfig = () => {
    return JSON.stringify({
      log: { level: 'info', timestamp: true },
      inbounds: [
        {
          type: 'tun',
          tag: 'tun-in',
          interface_name: tunConfig.adapterName,
          inet4_address: '10.66.77.2/24',
          mtu: tunConfig.mtu,
          auto_route: true,
          strict_route: tunConfig.strictRouting,
          stack: 'system',
          sniff: true
        }
      ],
      outbounds: [
        {
          type: 'masque',
          tag: 'aether-out',
          server: currentServer.serverAddress,
          server_port: currentServer.port,
          version: dpiConfig.masqueVersion,
          congestion_control: dpiConfig.congestionControl,
          tls: {
            enabled: true,
            fragment: {
              enabled: dpiConfig.tlsFragmentation,
              size: `${dpiConfig.fragMin}-${dpiConfig.fragMax}`,
              sleep: '0-5'
            }
          }
        },
        { type: 'direct', tag: 'direct' },
        { type: 'block', tag: 'block' }
      ],
      route: {
        auto_detect_interface: true,
        rules: [
          { ip_is_private: true, outbound: 'direct' },
          { protocol: 'dns', outbound: 'aether-out' }
        ]
      }
    }, null, 2);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    playSound.select();
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadExeBuilder = () => {
    const script = `@echo off
setlocal
title Aether VPN - Deltarune Edition (Windows Standalone Builder)
color 0B
cls

echo =========================================================================
echo    AETHER VPN (DELTARUNE EDITION) - 1-CLICK WINDOWS .EXE GENERATOR
echo =========================================================================
echo.

where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [X] Node.js is not found on your system!
    echo [*] Please install Node.js from https://nodejs.org (LTS version).
    pause
    exit /b 1
)

echo [1/3] Installing Electron desktop wrapper...
call npm install --save-dev electron electron-builder

echo.
echo [2/3] Compiling Deltarune Interface...
call npm run build

echo.
echo [3/3] Packaging into standalone Windows executable (Aether-VPN.exe)...
call npx electron-builder --win portable --dir

echo.
echo =========================================================================
echo [SUCCESS] Your Deltarune Aether VPN .exe is ready!
echo Output: dist_electron\\win-unpacked\\Aether VPN for Windows.exe
echo =========================================================================
pause
`;
    const blob = new Blob([script], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'build-windows-exe.bat';
    link.click();
    URL.revokeObjectURL(url);
    playSound.connected();
  };

  const handleDownloadBat = () => {
    const script = generateBatScript();
    const blob = new Blob([script], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'aether-tun-windows.bat';
    link.click();
    URL.revokeObjectURL(url);
    playSound.connected();
  };

  const handleDownloadConfig = () => {
    const config = generateSingBoxConfig();
    const blob = new Blob([config], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'aether-config.json';
    link.click();
    URL.revokeObjectURL(url);
    playSound.connected();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#090c1e] border-2 border-[#00f0ff] rounded-xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-[0_0_30px_rgba(0,240,255,0.3)] overflow-hidden font-mono text-xs">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#0d1330] border-b border-[#1c2752]">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#00f0ff]" />
            <h2 className="font-pixel text-xs text-white uppercase tracking-wider">
              Quick Windows Setup (No Coding Required)
            </h2>
          </div>
          <button
            onClick={() => {
              onClose();
              playSound.cancel();
            }}
            className="p-1 rounded text-[#7b8cb8] hover:text-white hover:bg-[#1a2347] transition-colors"
          >
            ✕
          </button>
        </div>

        {/* 4 Simple Tabs */}
        <div className="flex border-b border-[#1a244d] bg-[#0b0f24] text-[11px] overflow-x-auto">
          <button
            onClick={() => {
              setActiveTab('DELTARUNE_EXE');
              playSound.cursor();
            }}
            className={`flex-1 min-w-[160px] py-2.5 px-3 flex items-center justify-center gap-1.5 transition-colors border-b-2 font-bold ${
              activeTab === 'DELTARUNE_EXE'
                ? 'border-[#00ff66] text-[#00ff66] bg-[#12193d]'
                : 'border-transparent text-[#7b8cb8] hover:text-white'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Method 1: Package into .EXE (This Exact UI)</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('ONE_CLICK_BAT');
              playSound.cursor();
            }}
            className={`flex-1 min-w-[150px] py-2.5 px-3 flex items-center justify-center gap-1.5 transition-colors border-b-2 font-bold ${
              activeTab === 'ONE_CLICK_BAT'
                ? 'border-[#00f0ff] text-[#00f0ff] bg-[#12193d]'
                : 'border-transparent text-[#7b8cb8] hover:text-white'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Method 2: 1-Click .BAT Tunnel</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('SINGBOX');
              playSound.cursor();
            }}
            className={`flex-1 min-w-[140px] py-2.5 px-3 flex items-center justify-center gap-1.5 transition-colors border-b-2 font-bold ${
              activeTab === 'SINGBOX'
                ? 'border-[#ffe600] text-[#ffe600] bg-[#12193d]'
                : 'border-transparent text-[#7b8cb8] hover:text-white'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Method 3: Sing-box GUI Profile</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('AETHER_CLI');
              playSound.cursor();
            }}
            className={`flex-1 min-w-[140px] py-2.5 px-3 flex items-center justify-center gap-1.5 transition-colors border-b-2 font-bold ${
              activeTab === 'AETHER_CLI'
                ? 'border-[#ff007f] text-[#ff007f] bg-[#12193d]'
                : 'border-transparent text-[#7b8cb8] hover:text-white'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Method 4: Official Binary</span>
          </button>
        </div>

        {/* Tab 0: Deltarune Standalone .EXE */}
        {activeTab === 'DELTARUNE_EXE' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 text-[#d8e2ff]">
            <div className="p-3 bg-[#0d2116] border border-[#1b5e38] rounded-lg text-[11px] text-[#86efac] flex items-center gap-2">
              <Sparkles className="w-4 h-4 shrink-0 text-[#00ff66]" />
              <span>Turn this exact Deltarune Dark World web app into an installable desktop <strong>Aether-VPN.exe</strong> window on your PC!</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-[#0d1430] border border-[#212d5e] rounded-lg">
                <div className="flex items-center gap-2 text-[#00ff66] font-bold text-xs mb-1">
                  <span className="w-5 h-5 rounded-full bg-[#00ff66]/20 flex items-center justify-center text-[10px]">1</span>
                  Export as ZIP
                </div>
                <p className="text-[10px] text-[#8fa0cf]">Click <strong>Project Settings → Export as ZIP</strong> at the top right of AI Studio, then extract the ZIP on your PC.</p>
              </div>

              <div className="p-3 bg-[#0d1430] border border-[#212d5e] rounded-lg">
                <div className="flex items-center gap-2 text-[#00ff66] font-bold text-xs mb-1">
                  <span className="w-5 h-5 rounded-full bg-[#00ff66]/20 flex items-center justify-center text-[10px]">2</span>
                  Double-Click Script
                </div>
                <p className="text-[10px] text-[#8fa0cf]">Download or run <code>build-windows-exe.bat</code> (included in the root folder).</p>
              </div>

              <div className="p-3 bg-[#0d1430] border border-[#212d5e] rounded-lg">
                <div className="flex items-center gap-2 text-[#00ff66] font-bold text-xs mb-1">
                  <span className="w-5 h-5 rounded-full bg-[#00ff66]/20 flex items-center justify-center text-[10px]">3</span>
                  Open .EXE
                </div>
                <p className="text-[10px] text-[#8fa0cf]">Your desktop executable will appear in <code>dist_electron/win-unpacked/</code> ready to run!</p>
              </div>
            </div>

            <div className="p-4 bg-gradient-to-r from-[#0d2b1f] to-[#0c1c38] border border-[#00ff66]/50 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
              <div>
                <div className="font-bold text-white text-xs flex items-center gap-1.5">
                  <HardDrive className="w-4 h-4 text-[#00ff66]" />
                  Download 1-Click .EXE Builder File
                </div>
                <div className="text-[10px] text-[#8fa0cf] mt-0.5">
                  Pre-configured with electron-builder and frameless retro window styling.
                </div>
              </div>

              <button
                onClick={handleDownloadExeBuilder}
                className="px-4 py-2 bg-[#00ff66] hover:bg-[#5cff9e] text-black rounded text-[11px] font-bold shadow-[0_0_12px_rgba(0,255,102,0.4)] transition-all flex items-center gap-1.5 shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download build-windows-exe.bat</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 1: 1-Click .BAT */}
        {activeTab === 'ONE_CLICK_BAT' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 text-[#d8e2ff]">
            {/* Step cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3 bg-[#0d1430] border border-[#212d5e] rounded-lg">
                <div className="flex items-center gap-2 text-[#00f0ff] font-bold text-xs mb-1">
                  <span className="w-5 h-5 rounded-full bg-[#00f0ff]/20 flex items-center justify-center text-[10px]">1</span>
                  Download Script
                </div>
                <p className="text-[10px] text-[#8fa0cf]">Click the button below to download the ready-to-run <code>.bat</code> file.</p>
              </div>

              <div className="p-3 bg-[#0d1430] border border-[#212d5e] rounded-lg">
                <div className="flex items-center gap-2 text-[#00f0ff] font-bold text-xs mb-1">
                  <span className="w-5 h-5 rounded-full bg-[#00f0ff]/20 flex items-center justify-center text-[10px]">2</span>
                  Run as Admin
                </div>
                <p className="text-[10px] text-[#8fa0cf]">Right-click the file and choose <strong>"Run as administrator"</strong> in Windows.</p>
              </div>

              <div className="p-3 bg-[#0d1430] border border-[#212d5e] rounded-lg">
                <div className="flex items-center gap-2 text-[#00f0ff] font-bold text-xs mb-1">
                  <span className="w-5 h-5 rounded-full bg-[#00f0ff]/20 flex items-center justify-center text-[10px]">3</span>
                  Auto Setup
                </div>
                <p className="text-[10px] text-[#8fa0cf]">It automatically downloads <code>wintun.dll</code>, creates the adapter, and enables TUN mode!</p>
              </div>
            </div>

            {/* Download CTA */}
            <div className="p-4 bg-gradient-to-r from-[#0d193d] to-[#12224d] border border-[#00f0ff]/40 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
              <div>
                <div className="font-bold text-white text-xs flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#00ff66]" />
                  Pre-configured for: {currentServer.name}
                </div>
                <div className="text-[10px] text-[#8fa0cf] mt-0.5">
                  Includes MASQUE protocol, Wintun adapter config, and TLS anti-DPI fragmentation.
                </div>
              </div>

              <div className="flex gap-2 shrink-0">
                <button
                  onClick={() => handleCopy(generateBatScript())}
                  className="px-3 py-2 bg-[#172247] hover:bg-[#25356e] border border-[#2a3c78] text-white rounded text-[11px] font-bold flex items-center gap-1.5 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-[#00ff66]" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Script'}</span>
                </button>

                <button
                  onClick={handleDownloadBat}
                  className="px-4 py-2 bg-[#00f0ff] hover:bg-[#5cf4ff] text-black rounded text-[11px] font-bold shadow-[0_0_12px_rgba(0,240,255,0.4)] transition-all flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .BAT</span>
                </button>
              </div>
            </div>

            {/* Script preview */}
            <div className="bg-[#050714] border border-[#1b234a] rounded-lg p-3">
              <div className="text-[10px] text-[#7182b0] mb-1">Preview of generated script:</div>
              <pre className="text-[10px] text-[#00f0ff] overflow-x-auto max-h-40 leading-tight select-all">
                {generateBatScript()}
              </pre>
            </div>
          </div>
        )}

        {/* Tab 2: Sing-box / GUI Import */}
        {activeTab === 'SINGBOX' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 text-[#d8e2ff]">
            <div className="p-3 bg-[#171609] border border-[#4d4316] rounded-lg text-[11px] text-[#f2e59e]">
              If you prefer using an existing Windows client with a GUI (like <strong>sing-box GUI</strong>, <strong>NekoBox for Windows</strong>, or <strong>Hiddify</strong>), simply download and import this JSON configuration file.
            </div>

            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-xs">Generated TUN & MASQUE JSON Profile</span>
              <div className="flex gap-2">
                <button
                  onClick={() => handleCopy(generateSingBoxConfig())}
                  className="px-3 py-1.5 bg-[#172247] hover:bg-[#25356e] border border-[#2a3c78] text-white rounded text-[10px] font-bold flex items-center gap-1.5 transition-colors"
                >
                  {copied ? <Check className="w-3 h-3 text-[#00ff66]" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy JSON'}</span>
                </button>
                <button
                  onClick={handleDownloadConfig}
                  className="px-3.5 py-1.5 bg-[#ffe600] hover:bg-[#fff066] text-black rounded text-[10px] font-bold transition-all flex items-center gap-1.5"
                >
                  <Download className="w-3 h-3" />
                  <span>Download .json</span>
                </button>
              </div>
            </div>

            <pre className="bg-[#050714] border border-[#1b234a] rounded-lg p-3 text-[10px] text-[#ffe600] overflow-x-auto max-h-56 leading-relaxed select-all">
              {generateSingBoxConfig()}
            </pre>
          </div>
        )}

        {/* Tab 3: Official GitHub Release */}
        {activeTab === 'AETHER_CLI' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4 text-[#d8e2ff]">
            <div className="p-3 bg-[#1a0e26] border border-[#4d1f70] rounded-lg text-[11px] text-[#f0bafc]">
              Download the official pre-compiled Windows executable directly from the CluvexStudio GitHub releases page.
            </div>

            <div className="space-y-3">
              <div className="p-3 bg-[#0c122b] border border-[#1d2754] rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-white text-xs">Official Aether v1.8.0 GitHub Release</div>
                  <div className="text-[10px] text-[#7d8fb8]">github.com/CluvexStudio/Aether/releases/tag/v1.8.0</div>
                </div>
                <a
                  href="https://github.com/CluvexStudio/Aether/releases/tag/v1.8.0"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-[#ff007f] hover:bg-[#ff4db8] text-white rounded text-[10px] font-bold flex items-center gap-1 transition-all"
                >
                  <span>Open GitHub</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              <div className="p-3 bg-[#0c122b] border border-[#1d2754] rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-white text-xs">Official Wintun Driver for Windows</div>
                  <div className="text-[10px] text-[#7d8fb8]">www.wintun.net (official WireGuard Layer-3 TUN driver)</div>
                </div>
                <a
                  href="https://www.wintun.net/"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-[#00f0ff] hover:bg-[#6beeff] text-black rounded text-[10px] font-bold flex items-center gap-1 transition-all"
                >
                  <span>Get Wintun.dll</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="p-3 bg-[#0d1330] border-t border-[#1c2752] flex items-center justify-end">
          <button
            onClick={() => {
              onClose();
              playSound.select();
            }}
            className="px-4 py-1.5 rounded bg-[#00f0ff] hover:bg-[#5ef5ff] text-black font-pixel text-[10px] shadow-[0_0_10px_rgba(0,240,255,0.4)]"
          >
            GOT IT!
          </button>
        </div>
      </div>
    </div>
  );
};
