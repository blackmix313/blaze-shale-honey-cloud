import React, { useState } from 'react';
import { RoutingRule } from '../types/vpn';
import { playSound } from '../utils/audio';
import { 
  Sparkles, 
  X, 
  Check, 
  Plus, 
  Trash2, 
  ShieldCheck, 
  Globe, 
  Ban, 
  ArrowRightLeft,
  Info,
  RotateCcw
} from 'lucide-react';

interface RoutingRulesModalProps {
  rules: RoutingRule[];
  onSaveRules: (rules: RoutingRule[]) => void;
  onClose: () => void;
}

export const RoutingRulesModal: React.FC<RoutingRulesModalProps> = ({
  rules: initialRules,
  onSaveRules,
  onClose
}) => {
  const [rules, setRules] = useState<RoutingRule[]>([...initialRules]);
  const [ruleName, setRuleName] = useState('');
  const [ruleType, setRuleType] = useState<RoutingRule['type']>('domain-suffix');
  const [ruleValue, setRuleValue] = useState('');
  const [ruleAction, setRuleAction] = useState<RoutingRule['action']>('proxy');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleAddRule = () => {
    if (!ruleValue.trim()) return;
    const newRule: RoutingRule = {
      id: `rule-${Date.now()}`,
      name: ruleName.trim() || `Rule for ${ruleValue.split(',')[0]}`,
      type: ruleType,
      value: ruleValue.trim(),
      action: ruleAction,
      enabled: true
    };
    setRules([...rules, newRule]);
    setRuleName('');
    setRuleValue('');
    playSound.select();
  };

  const handleRemoveRule = (id: string) => {
    setRules(rules.filter((r) => r.id !== id));
    playSound.cancel();
  };

  const handleToggleRule = (id: string) => {
    setRules(
      rules.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r))
    );
    playSound.cursor();
  };

  const handleSave = () => {
    onSaveRules(rules);
    playSound.connected();
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#090c1e] border-2 border-[#ff007f] rounded-xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-[0_0_25px_rgba(255,0,127,0.25)] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#0d122c] border-b border-[#1c244c]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#ff007f]" />
            <h2 className="font-pixel text-xs text-white uppercase tracking-wider">
              MERCY: Aether Smart Routing & Domain Dispatcher
            </h2>
          </div>
          <button
            onClick={() => {
              onClose();
              playSound.cancel();
            }}
            className="p-1 rounded text-[#7b8bbd] hover:text-white hover:bg-[#1a2347] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs font-mono text-[#d6deff]">
          {/* Info Banner */}
          <div className="p-3 bg-[#1c0d1f] border border-[#521c4b] rounded-lg flex items-start gap-2.5">
            <Info className="w-4 h-4 text-[#ff007f] shrink-0 mt-0.5" />
            <p className="text-[11px] text-[#f7b0e2] leading-relaxed">
              Define how specific domains, IP CIDR ranges, and SNI hosts are dispatched. Requests can be <strong>Proxied</strong> via Wintun TUN, <strong>Direct</strong> for local speed, or <strong>Blocked</strong> for ad/telemetry rejection.
            </p>
          </div>

          {/* Add New Rule Form */}
          <div className="space-y-3 bg-[#0b0f26] p-3.5 rounded-lg border border-[#1d2654]">
            <h3 className="font-pixel text-[10px] text-[#ff007f] uppercase">Add New Dispatch Rule</h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="Rule Label (e.g. Discord Voice Direct)"
                value={ruleName}
                onChange={(e) => setRuleName(e.target.value)}
                className="bg-[#111636] border border-[#232f63] rounded px-2.5 py-1.5 text-white outline-none focus:border-[#ff007f]"
              />

              <div className="grid grid-cols-2 gap-2">
                <select
                  value={ruleType}
                  onChange={(e) => setRuleType(e.target.value as any)}
                  className="bg-[#111636] border border-[#232f63] rounded px-2 py-1.5 text-white outline-none"
                >
                  <option value="domain-suffix">Domain Suffix</option>
                  <option value="domain">Exact Domain</option>
                  <option value="ip-cidr">IP CIDR</option>
                  <option value="geoip">GeoIP Country</option>
                </select>

                <select
                  value={ruleAction}
                  onChange={(e) => setRuleAction(e.target.value as any)}
                  className="bg-[#111636] border border-[#232f63] rounded px-2 py-1.5 text-white outline-none font-bold"
                >
                  <option value="proxy">PROXY (TUN)</option>
                  <option value="direct">DIRECT (Bypass)</option>
                  <option value="block">BLOCK (Drop)</option>
                </select>
              </div>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Value (e.g. discord.gg, 192.168.1.0/24, or CN)"
                value={ruleValue}
                onChange={(e) => setRuleValue(e.target.value)}
                className="flex-1 bg-[#111636] border border-[#232f63] rounded px-2.5 py-1.5 text-white outline-none focus:border-[#ff007f]"
              />
              <button
                onClick={handleAddRule}
                className="px-4 py-1.5 bg-[#ff007f] hover:bg-[#ff4db8] text-white rounded text-[10px] font-pixel shadow-[0_0_8px_rgba(255,0,127,0.4)] transition-all flex items-center gap-1 shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                ADD RULE
              </button>
            </div>
          </div>

          {/* Active Rules List */}
          <div className="space-y-2">
            <h3 className="font-pixel text-[10px] text-white uppercase">Active Routing Table</h3>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {rules.map((rule) => (
                <div
                  key={rule.id}
                  className={`p-2.5 rounded-lg border transition-all flex items-center justify-between gap-3 ${
                    rule.enabled
                      ? 'border-[#222d5a] bg-[#0c1028]'
                      : 'border-[#171c38] bg-[#080a18] opacity-50'
                  }`}
                >
                  {/* Left */}
                  <div className="flex items-center gap-2.5 flex-1 min-w-0">
                    <input
                      type="checkbox"
                      checked={rule.enabled}
                      onChange={() => handleToggleRule(rule.id)}
                      className="accent-[#ff007f] w-4 h-4 rounded shrink-0 cursor-pointer"
                    />

                    <div className="min-w-0">
                      <div className="font-bold text-white text-[11px] truncate flex items-center gap-2">
                        <span>{rule.name}</span>
                        <span className="px-1 py-0.2 rounded bg-[#161d3d] text-[8px] text-[#7a8bb8] border border-[#232e5e]">
                          {rule.type}
                        </span>
                      </div>
                      <div className="text-[9px] text-[#7888b5] font-mono truncate">{rule.value}</div>
                    </div>
                  </div>

                  {/* Right Action Badge & Delete */}
                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`px-2 py-0.5 rounded text-[9px] font-pixel uppercase ${
                        rule.action === 'proxy'
                          ? 'bg-[#00f0ff]/20 text-[#00f0ff] border border-[#00f0ff]/40'
                          : rule.action === 'direct'
                          ? 'bg-[#00ff66]/20 text-[#00ff66] border border-[#00ff66]/40'
                          : 'bg-[#ff2a2a]/20 text-[#ff2a2a] border border-[#ff2a2a]/40'
                      }`}
                    >
                      {rule.action}
                    </span>

                    <button
                      onClick={() => handleRemoveRule(rule.id)}
                      className="p-1 text-[#62719c] hover:text-red-400 transition-colors"
                      title="Delete Rule"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-[#0d122c] border-t border-[#1c244c] flex items-center justify-end gap-2">
          <button
            onClick={() => {
              onClose();
              playSound.cancel();
            }}
            className="px-3.5 py-1.5 rounded bg-[#131a3d] hover:bg-[#1d2757] text-[#9aa7d4] text-[10px] font-pixel transition-colors"
          >
            CANCEL
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-1.5 rounded bg-[#ff007f] hover:bg-[#ff4db8] text-white text-[10px] font-pixel shadow-[0_0_10px_rgba(255,0,127,0.5)] transition-all flex items-center gap-1.5"
          >
            {saveSuccess ? (
              <>
                <Check className="w-3.5 h-3.5" />
                RULES APPLIED!
              </>
            ) : (
              'SAVE ROUTING'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
