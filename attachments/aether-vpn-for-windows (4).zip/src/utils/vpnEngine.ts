import { ServerNode, TunConfig, DpiEvasionConfig, RoutingRule, LogEntry } from '../types/vpn';

export const DEFAULT_SERVERS: ServerNode[] = [
  {
    id: 'castle-town-1',
    name: 'Castle Town Gateway (Primary Fountain)',
    darkWorldZone: 'Castle Town',
    country: 'United States',
    city: 'San Francisco, CA',
    flag: '🇺🇸',
    ping: 28,
    protocol: 'MASQUE_H3',
    serverAddress: 'us-west.aether-tunnel.net',
    port: 443,
    load: 24,
    isFavorite: true,
    features: ['Wintun Native', 'MASQUE HTTP/3', 'Zero-RTT', 'TLS Frag']
  },
  {
    id: 'cyber-city-1',
    name: 'Cyber City Core (Queen’s Grid)',
    darkWorldZone: 'Cyber City',
    country: 'Japan',
    city: 'Tokyo',
    flag: '🇯🇵',
    ping: 34,
    protocol: 'NESTED_WIREGUARD_MASQUE',
    serverAddress: 'jp-tyo.aether-darkworld.org',
    port: 8443,
    load: 42,
    isFavorite: true,
    features: ['Nested WG', 'BBRv3 Congestion', 'Anti-DPI Shield']
  },
  {
    id: 'spamton-alley',
    name: 'Spamton NEO [Hyperlink Blocked] Evasion Node',
    darkWorldZone: 'Trash Zone',
    country: 'Germany',
    city: 'Frankfurt',
    flag: '🇩🇪',
    ping: 58,
    protocol: 'MASQUE_H2',
    serverAddress: 'de-fra.big-shot-vpn.xyz',
    port: 443,
    load: 18,
    isFavorite: false,
    features: ['Aggressive TLS Split', 'Noise Padding', 'Big Shot Mode']
  },
  {
    id: 'card-castle',
    name: 'Card Kingdom Relay (King’s Court)',
    darkWorldZone: 'Card Kingdom',
    country: 'United Kingdom',
    city: 'London',
    flag: '🇬🇧',
    ping: 65,
    protocol: 'WIREGUARD',
    serverAddress: 'uk-lon.aether-wintun.io',
    port: 51820,
    load: 35,
    isFavorite: false,
    features: ['WireGuard-NT', 'Kernel Mode TUN', 'Direct UDP']
  },
  {
    id: 'cyber-field',
    name: 'Cyber Field Beats (Sweet Cap’n Cakes)',
    darkWorldZone: 'Cyber Field',
    country: 'Singapore',
    city: 'Singapore',
    flag: '🇸🇬',
    ping: 45,
    protocol: 'VLESS_REALITY',
    serverAddress: 'sg-sin.aether-flow.net',
    port: 443,
    load: 51,
    isFavorite: false,
    features: ['Reality SNI Steal', 'Zero Leak TUN', 'IPv6 Ready']
  },
  {
    id: 'dark-fountain-seoul',
    name: 'Pure Fountain Anchor (Goner Relay)',
    darkWorldZone: 'Dark Fountain',
    country: 'South Korea',
    city: 'Seoul',
    flag: '🇰🇷',
    ping: 39,
    protocol: 'SHADOWSOCKS_2022',
    serverAddress: 'kr-icn.aether-core.dev',
    port: 8388,
    load: 29,
    isFavorite: true,
    features: ['2022-BLAKE3-AES', 'Wintun Layer 3', 'High Speed']
  }
];

export const DEFAULT_TUN_CONFIG: TunConfig = {
  enabled: true,
  driver: 'wintun',
  adapterName: 'Aether-TUN0',
  virtualIp: '10.66.77.2/24',
  gateway: '10.66.77.1',
  mtu: 1420,
  dnsServers: ['1.1.1.1', '1.0.0.1', '9.9.9.9'],
  strictRouting: true,
  ipv6Routing: false,
  fakeDns: true,
  bypassLan: true,
  killSwitch: true,
  splitTunneling: {
    enabled: false,
    mode: 'exclude',
    apps: [
      { name: 'Steam.exe', path: 'C:\\Program Files (x86)\\Steam\\steam.exe', icon: 'Gamepad2', enabled: true },
      { name: 'Discord.exe', path: 'C:\\Users\\User\\AppData\\Local\\Discord\\app.exe', icon: 'MessageSquare', enabled: false },
      { name: 'Spotify.exe', path: 'C:\\Users\\User\\AppData\\Roaming\\Spotify\\spotify.exe', icon: 'Music', enabled: false }
    ]
  }
};

export const DEFAULT_DPI_CONFIG: DpiEvasionConfig = {
  tlsFragmentation: true,
  fragMin: 8,
  fragMax: 24,
  masqueVersion: 'HTTP3',
  congestionControl: 'BBRv3',
  obfuscationSeed: 'DELTARUNE_DETERMINATION_AETHER_V180',
  noisePadding: true,
  zeroRtt: true,
  alpnSpoofing: 'h3',
  udpGso: true
};

export const DEFAULT_ROUTING_RULES: RoutingRule[] = [
  { id: '1', name: 'Bypass Local Network (LAN)', type: 'ip-cidr', value: '192.168.0.0/16, 10.0.0.0/8, 127.0.0.1/32', action: 'direct', enabled: true },
  { id: '2', name: 'DPI Protected Domains (Global Proxy)', type: 'domain-suffix', value: 'google.com, youtube.com, github.com, twitter.com, x.com, telegram.org', action: 'proxy', enabled: true },
  { id: '3', name: 'Anti-Tracking & Malicious Adware', type: 'domain-suffix', value: 'telemetry.microsoft.com, adservice.google.com, doubleclick.net', action: 'block', enabled: true },
  { id: '4', name: 'Steam Game Traffic (Direct Latency)', type: 'domain-suffix', value: 'steamcontent.com, steampowered.com, epicgames.com', action: 'direct', enabled: false },
  { id: '5', name: 'Dark World Fountain Overrides', type: 'domain', value: 'deltarune.com, toby.fangamer.com, fangamer.com', action: 'proxy', enabled: true }
];

export const DELTARUNE_QUOTES = [
  {
    speaker: 'Ralsei',
    avatar: '🐑',
    quote: 'Kris, our connection is now shielded with TUN mode! No dark firewalls can block our light!',
    color: '#00ff66'
  },
  {
    speaker: 'Susie',
    avatar: '🦖',
    quote: 'If any DPI firewall tries to inspect our packets, I\'m gonna smash their filters into pieces!!',
    color: '#ff007f'
  },
  {
    speaker: 'Spamton NEO',
    avatar: '🎭',
    quote: 'NOW\'S YOUR CHANCE TO BE A [[BIG SHOT]]!! WITH 100% [Encrypted WireGuard] AND [Zero DNS Leaks]!!',
    color: '#ffe600'
  },
  {
    speaker: 'Queen',
    avatar: '👑',
    quote: 'LMAO Inspecting Packets Is So Yesterday. My MASQUE HTTP/3 Tunnel Has 0ms Jitter Potassium Power.',
    color: '#00f0ff'
  },
  {
    speaker: 'Kris (SOUL)',
    avatar: '❤️',
    quote: 'Your SOUL shines with DETERMINATION. The system-wide TUN device routes all your dreams.',
    color: '#ff2a2a'
  }
];

export const INITIAL_LOGS: LogEntry[] = [
  { id: '1', timestamp: '14:14:02.108', level: 'INFO', tag: 'AETHER_CORE', message: 'Aether v1.8.0 Windows Engine initialized. Rust runtime target: x86_64-pc-windows-msvc' },
  { id: '2', timestamp: '14:14:02.140', level: 'TUN', tag: 'WINTUN', message: 'Loaded wintun.dll (v0.14.1). Virtual TUN adapter driver registered successfully.' },
  { id: '3', timestamp: '14:14:02.195', level: 'DPI', tag: 'FRAGMENT', message: 'TLS ClientHello fragmentation engine active: chunk size bounds [8, 24] bytes.' },
  { id: '4', timestamp: '14:14:02.250', level: 'SOUL', tag: 'DARK_WORLD', message: 'Dark World Fountain Resonance calibrated. Tension Points (TP) gauge linked.' },
  { id: '5', timestamp: '14:14:02.312', level: 'INFO', tag: 'ROUTING', message: 'Loaded 5 default routing rules and 6 Dark World Edge Gateways.' }
];
