import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { 
  ConnectionState, 
  SoulColor, 
  ServerNode, 
  TunConfig, 
  DpiEvasionConfig, 
  RoutingRule, 
  LogEntry, 
  TrafficStats 
} from './types/vpn';
import { 
  DEFAULT_SERVERS, 
  DEFAULT_TUN_CONFIG, 
  DEFAULT_DPI_CONFIG, 
  DEFAULT_ROUTING_RULES, 
  INITIAL_LOGS 
} from './utils/vpnEngine';
import { playSound } from './utils/audio';

import { TitleBar } from './components/TitleBar';
import { BattleMenuBar, ActiveTab } from './components/BattleMenuBar';
import { MainDashboard } from './components/MainDashboard';
import { TunSettingsModal } from './components/TunSettingsModal';
import { DpiSettingsModal } from './components/DpiSettingsModal';
import { ServerListModal } from './components/ServerListModal';
import { RoutingRulesModal } from './components/RoutingRulesModal';
import { DiagnosticsLogModal } from './components/DiagnosticsLogModal';
import { WindowsTraySim } from './components/WindowsTraySim';
import { QuickSetupModal } from './components/QuickSetupModal';

export default function App() {
  // Core VPN State
  const [connectionState, setConnectionState] = useState<ConnectionState>('DISCONNECTED');
  const [soulColor, setSoulColor] = useState<SoulColor>('RED');
  const [servers, setServers] = useState<ServerNode[]>(DEFAULT_SERVERS);
  const [currentServer, setCurrentServer] = useState<ServerNode>(DEFAULT_SERVERS[0]);
  const [tunConfig, setTunConfig] = useState<TunConfig>(DEFAULT_TUN_CONFIG);
  const [dpiConfig, setDpiConfig] = useState<DpiEvasionConfig>(DEFAULT_DPI_CONFIG);
  const [routingRules, setRoutingRules] = useState<RoutingRule[]>(DEFAULT_ROUTING_RULES);
  const [logs, setLogs] = useState<LogEntry[]>(INITIAL_LOGS);

  // Active View / Modal Tab
  const [activeTab, setActiveTab] = useState<ActiveTab>('DASHBOARD');

  // Window State
  const [isMaximized, setIsMaximized] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [showTraySim, setShowTraySim] = useState(true);

  // Live Traffic Stats
  const [trafficStats, setTrafficStats] = useState<TrafficStats>({
    downloadSpeed: 0,
    uploadSpeed: 0,
    totalDownloaded: 142 * 1024 * 1024,
    totalUploaded: 28 * 1024 * 1024,
    ping: currentServer.ping,
    jitter: 1.2,
    packetLoss: 0,
    tensionPoints: 0,
    healthPoints: 100,
    uptimeSeconds: 0
  });

  const connectionTimerRef = useRef<NodeJS.Timeout | null>(null);

  const addLog = (level: LogEntry['level'], tag: string, message: string) => {
    const now = new Date();
    const ts = `${now.toTimeString().split(' ')[0]}.${now.getMilliseconds().toString().padStart(3, '0')}`;
    const newEntry: LogEntry = {
      id: `log-${Date.now()}-${Math.random()}`,
      timestamp: ts,
      level,
      tag,
      message
    };
    setLogs((prev) => [...prev.slice(-250), newEntry]);
  };

  // Sparkles Confetti burst on SOUL Connection
  const triggerSoulVictoryBurst = (color: SoulColor) => {
    const hexMap = {
      RED: '#ff2a2a',
      CYAN: '#00f0ff',
      YELLOW: '#ffe600',
      GREEN: '#00ff66'
    };
    try {
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.6 },
        colors: [hexMap[color], '#ffffff', '#a855f7', '#ff007f']
      });
    } catch {
      // Ignore
    }
  };

  // Real-time Traffic Simulator loop
  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (connectionState === 'CONNECTED') {
      interval = setInterval(() => {
        setTrafficStats((prev) => {
          // Generate realistic bandwidth bursts
          const baseDownload = 12 * 1024 * 1024; // 12 MB/s
          const randomFactor = 0.6 + Math.random() * 0.9;
          const currentDown = Math.floor(baseDownload * randomFactor);
          const currentUp = Math.floor(currentDown * 0.22);

          const pingFluct = currentServer.ping + (Math.floor(Math.random() * 5) - 2);
          const jitterVal = +(Math.random() * 1.8 + 0.4).toFixed(1);
          const tpPercent = Math.min(100, Math.max(25, Math.floor((currentDown / (24 * 1024 * 1024)) * 100)));

          return {
            ...prev,
            downloadSpeed: currentDown,
            uploadSpeed: currentUp,
            totalDownloaded: prev.totalDownloaded + currentDown,
            totalUploaded: prev.totalUploaded + currentUp,
            ping: Math.max(12, pingFluct),
            jitter: jitterVal,
            tensionPoints: tpPercent,
            healthPoints: Math.max(88, 100 - Math.floor(jitterVal * 2)),
            uptimeSeconds: prev.uptimeSeconds + 1
          };
        });

        // Occasional DPI & Packet logs
        if (Math.random() > 0.75) {
          const dpiMsgs = [
            `SOCKS5 [127.0.0.1:10808] -> TUN [10.66.77.2]: Dispatched TLS 1.3 ClientHello (split chunk size: ${dpiConfig.fragMin} bytes).`,
            `Wintun Layer-3 I/O: 1420 bytes transmitted with 0.0% packet drop. Congestion window: ${dpiConfig.congestionControl}.`,
            `Zero-RTT session resumption token verified with gateway [${currentServer.serverAddress}].`,
            `DNS DoH request resolved via 1.1.1.1 (0ms cached). Anti-SNI evasion shield active.`
          ];
          const randomMsg = dpiMsgs[Math.floor(Math.random() * dpiMsgs.length)];
          addLog('DPI', 'DPI_SHIELD', randomMsg);
        }
      }, 1000);
    } else {
      setTrafficStats((prev) => ({
        ...prev,
        downloadSpeed: 0,
        uploadSpeed: 0,
        tensionPoints: 0,
        uptimeSeconds: 0,
        ping: currentServer.ping
      }));
    }

    return () => clearInterval(interval);
  }, [connectionState, currentServer, dpiConfig]);

  // Connect / Disconnect flow
  const handleToggleConnect = () => {
    if (connectionState === 'CONNECTED' || connectionState === 'RECONNECTING') {
      // Disconnect
      if (connectionTimerRef.current) clearTimeout(connectionTimerRef.current);
      setConnectionState('DISCONNECTED');
      playSound.cancel();
      addLog('INFO', 'DISCONNECT', `Terminating tunnel session to ${currentServer.name}...`);
      addLog('TUN', 'WINTUN', `Wintun adapter "${tunConfig.adapterName}" session closed. Routing tables restored to default.`);
      return;
    }

    // Begin Connection Lifecycle
    playSound.heartbeat();
    setConnectionState('DISCOVERING');
    addLog('INFO', 'INITIATE', `Discovering optimal Dark World route to "${currentServer.name}" (${currentServer.serverAddress}:${currentServer.port})...`);

    // Step 2: TLS Fragmentation
    connectionTimerRef.current = setTimeout(() => {
      setConnectionState('FRAGMENTING_TLS');
      playSound.dpiFragment();
      addLog('DPI', 'TLS_FRAG', `Slicing TLS 1.3 ClientHello into [${dpiConfig.fragMin}, ${dpiConfig.fragMax}] byte micro-segments. Entropy seed applied.`);

      // Step 3: TUN Driver Allocation
      connectionTimerRef.current = setTimeout(() => {
        setConnectionState('ALLOCATING_TUN');
        playSound.tunEngage();
        addLog('TUN', 'WINTUN', `Spawning Wintun Layer-3 Virtual Adapter: ${tunConfig.adapterName} (Virtual IP: ${tunConfig.virtualIp}, MTU: ${tunConfig.mtu}).`);

        // Step 4: Handshake & Masque Session
        connectionTimerRef.current = setTimeout(() => {
          setConnectionState('HANDSHAKING');
          addLog('INFO', 'MASQUE', `Establishing ${currentServer.protocol} tunnel over UDP. Zero-RTT early data validated.`);

          // Step 5: Connected & TP Sync
          connectionTimerRef.current = setTimeout(() => {
            setConnectionState('CONNECTED');
            playSound.connected();
            triggerSoulVictoryBurst(soulColor);
            addLog('SOUL', 'VICTORY', `Tunnel connected successfully! Tension Points (TP) synchronized with Dark Fountain. All Windows traffic shielded.`);
          }, 600);
        }, 500);
      }, 500);
    }, 500);
  };

  const handleSelectServer = (server: ServerNode) => {
    const isCurrent = currentServer.id === server.id;
    setCurrentServer(server);
    setActiveTab('DASHBOARD');
    addLog('INFO', 'GATEWAY', `Selected Dark World Gateway: ${server.name} (${server.serverAddress})`);

    if (connectionState === 'CONNECTED' && !isCurrent) {
      addLog('INFO', 'MIGRATE', `Re-routing Wintun tunnel to new endpoint ${server.serverAddress}...`);
      handleToggleConnect();
      setTimeout(() => {
        handleToggleConnect();
      }, 700);
    }
  };

  return (
    <div className="w-screen h-screen bg-[#050711] text-[#e0e7fc] flex items-center justify-center p-0 md:p-3 overflow-hidden font-sans">
      {/* Minimized Placeholder banner */}
      {isMinimized && (
        <div className="text-center p-6 bg-[#0c1026] border border-[#202957] rounded-xl shadow-2xl space-y-3 animate-in fade-in">
          <div className="font-pixel text-xs text-[#00f0ff]">Aether VPN is Minimized in System Tray</div>
          <p className="text-xs font-mono text-[#8a99c9]">Check the bottom-right tray icon or click below to restore.</p>
          <button
            onClick={() => {
              setIsMinimized(false);
              playSound.select();
            }}
            className="px-4 py-2 bg-[#00f0ff] hover:bg-[#6ef8ff] text-black font-pixel text-xs rounded shadow-[0_0_12px_rgba(0,240,255,0.5)] transition-all"
          >
            RESTORE WINDOW
          </button>
        </div>
      )}

      {/* Main Windows Client Container */}
      {!isMinimized && (
        <div 
          className={`bg-[#080b18] border-2 border-[#1c244c] flex flex-col overflow-hidden transition-all duration-200 shadow-[0_0_50px_rgba(0,0,0,0.85)] ${
            isMaximized ? 'w-full h-full rounded-none' : 'w-full max-w-5xl h-full md:h-[94vh] rounded-xl'
          }`}
        >
          {/* Windows Titlebar */}
          <TitleBar
            connectionState={connectionState}
            soulColor={soulColor}
            onSoulColorChange={(c) => {
              setSoulColor(c);
              addLog('SOUL', 'POWER', `SOUL Power Mode shifted to: ${c}`);
            }}
            onMinimize={() => setIsMinimized(true)}
            onMaximize={() => setIsMaximized(!isMaximized)}
            onClose={() => {
              addLog('INFO', 'QUIT', 'Aether Windows Client minimized to notification tray.');
              setIsMinimized(true);
            }}
            showTraySim={showTraySim}
            onToggleTraySim={() => setShowTraySim(!showTraySim)}
            onOpenQuickSetup={() => setActiveTab('QUICK_SETUP')}
          />

          {/* Main Content Area */}
          <div className="flex-1 flex flex-col overflow-hidden relative">
            <MainDashboard
              currentServer={currentServer}
              connectionState={connectionState}
              soulColor={soulColor}
              trafficStats={trafficStats}
              tunConfig={tunConfig}
              dpiConfig={dpiConfig}
              onToggleConnect={handleToggleConnect}
              onOpenServers={() => setActiveTab('SERVERS')}
              onOpenTun={() => setActiveTab('TUN_SETTINGS')}
              onOpenDpi={() => setActiveTab('DPI_SETTINGS')}
              onOpenQuickSetup={() => setActiveTab('QUICK_SETUP')}
            />
          </div>

          {/* Deltarune Battle Buttons Menu */}
          <BattleMenuBar
            activeTab={activeTab}
            onSelectTab={(tab) => setActiveTab(tab)}
            connectionState={connectionState}
            onToggleConnect={handleToggleConnect}
            soulColor={soulColor}
          />
        </div>
      )}

      {/* Modals & Sub-Screens */}
      {activeTab === 'TUN_SETTINGS' && (
        <TunSettingsModal
          config={tunConfig}
          onSave={(cfg) => {
            setTunConfig(cfg);
            addLog('TUN', 'WINTUN_CONFIG', `Applied Wintun Driver settings: Adapter=${cfg.adapterName}, IP=${cfg.virtualIp}, MTU=${cfg.mtu}`);
          }}
          onClose={() => setActiveTab('DASHBOARD')}
        />
      )}

      {activeTab === 'DPI_SETTINGS' && (
        <DpiSettingsModal
          config={dpiConfig}
          onSave={(cfg) => {
            setDpiConfig(cfg);
            addLog('DPI', 'EVASION_CONFIG', `TLS Fragment Bounds: [${cfg.fragMin}, ${cfg.fragMax}], Congestion: ${cfg.congestionControl}`);
          }}
          onClose={() => setActiveTab('DASHBOARD')}
        />
      )}

      {activeTab === 'SERVERS' && (
        <ServerListModal
          servers={servers}
          selectedServer={currentServer}
          onSelectServer={handleSelectServer}
          onClose={() => setActiveTab('DASHBOARD')}
        />
      )}

      {activeTab === 'ROUTING' && (
        <RoutingRulesModal
          rules={routingRules}
          onSaveRules={(rls) => {
            setRoutingRules(rls);
            addLog('INFO', 'ROUTING', `Routing rules table updated (${rls.length} rules active).`);
          }}
          onClose={() => setActiveTab('DASHBOARD')}
        />
      )}

      {activeTab === 'LOGS' && (
        <DiagnosticsLogModal
          logs={logs}
          onClearLogs={() => setLogs([])}
          onClose={() => setActiveTab('DASHBOARD')}
        />
      )}

      {activeTab === 'QUICK_SETUP' && (
        <QuickSetupModal
          currentServer={currentServer}
          tunConfig={tunConfig}
          dpiConfig={dpiConfig}
          onClose={() => setActiveTab('DASHBOARD')}
        />
      )}

      {/* Windows System Tray Simulator */}
      {showTraySim && (
        <WindowsTraySim
          currentServer={currentServer}
          connectionState={connectionState}
          soulColor={soulColor}
          trafficStats={trafficStats}
          onToggleConnect={handleToggleConnect}
          onRestoreWindow={() => setIsMinimized(false)}
          onClose={() => setShowTraySim(false)}
        />
      )}
    </div>
  );
}
