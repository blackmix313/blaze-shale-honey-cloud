export type VpnProtocol = 
  | 'MASQUE_H3' 
  | 'MASQUE_H2' 
  | 'WIREGUARD' 
  | 'NESTED_WIREGUARD_MASQUE' 
  | 'SHADOWSOCKS_2022' 
  | 'VLESS_REALITY';

export type ConnectionState = 
  | 'DISCONNECTED'
  | 'DISCOVERING'
  | 'FRAGMENTING_TLS'
  | 'ALLOCATING_TUN'
  | 'HANDSHAKING'
  | 'CONNECTED'
  | 'RECONNECTING'
  | 'ERROR';

export type SoulColor = 'RED' | 'CYAN' | 'YELLOW' | 'GREEN';

export interface TunConfig {
  enabled: boolean;
  driver: 'wintun' | 'wireguard-nt' | 'tap-windows6';
  adapterName: string;
  virtualIp: string;
  gateway: string;
  mtu: number;
  dnsServers: string[];
  strictRouting: boolean;
  ipv6Routing: boolean;
  fakeDns: boolean;
  bypassLan: boolean;
  killSwitch: boolean;
  splitTunneling: {
    enabled: boolean;
    mode: 'exclude' | 'include';
    apps: { name: string; path: string; icon: string; enabled: boolean }[];
  };
}

export interface DpiEvasionConfig {
  tlsFragmentation: boolean;
  fragMin: number;
  fragMax: number;
  masqueVersion: 'HTTP3' | 'HTTP2' | 'AUTO';
  congestionControl: 'BBR' | 'CUBIC' | 'BBRv3';
  obfuscationSeed: string;
  noisePadding: boolean;
  zeroRtt: boolean;
  alpnSpoofing: 'h3' | 'h2' | 'http/1.1' | 'randomized';
  udpGso: boolean;
}

export interface ServerNode {
  id: string;
  name: string;
  darkWorldZone: string;
  country: string;
  city: string;
  flag: string;
  ping: number;
  protocol: VpnProtocol;
  serverAddress: string;
  port: number;
  load: number;
  isFavorite?: boolean;
  features: string[];
}

export interface TrafficStats {
  downloadSpeed: number; // bytes/sec
  uploadSpeed: number;   // bytes/sec
  totalDownloaded: number; // bytes
  totalUploaded: number;   // bytes
  ping: number;
  jitter: number;
  packetLoss: number;
  tensionPoints: number; // 0 to 100 (Deltarune TP)
  healthPoints: number;  // 0 to 100 (Deltarune HP)
  uptimeSeconds: number;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  level: 'INFO' | 'DPI' | 'TUN' | 'WARN' | 'ERROR' | 'SOUL';
  tag: string;
  message: string;
}

export interface RoutingRule {
  id: string;
  name: string;
  type: 'domain' | 'domain-suffix' | 'ip-cidr' | 'geoip' | 'process';
  value: string;
  action: 'proxy' | 'direct' | 'block';
  enabled: boolean;
}
