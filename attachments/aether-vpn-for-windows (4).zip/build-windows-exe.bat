@echo off
setlocal
title Aether VPN - Deltarune Edition (Windows Standalone Builder)
color 0B
cls

echo =========================================================================
echo    AETHER VPN (DELTARUNE EDITION) - 1-CLICK WINDOWS .EXE GENERATOR
echo =========================================================================
echo.

:: Check Node.js
where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [X] Node.js is not found on your system!
    echo [*] Please install Node.js from https://nodejs.org (LTS version).
    pause
    exit /b 1
)

echo [1/3] Installing builder dependencies...
call npm install --save-dev electron electron-builder

echo.
echo [2/3] Compiling Deltarune Interface...
call npm run build

echo.
echo [3/3] Packaging into standalone Windows executable (Aether-VPN.exe)...
call npx electron-builder --win portable --dir

echo.
echo =========================================================================
echo [SUCCESS] Your Deltarune Aether VPN .exe is ready!
echo Folder: dist_electron/win-unpacked/Aether VPN for Windows.exe
echo =========================================================================
pause
